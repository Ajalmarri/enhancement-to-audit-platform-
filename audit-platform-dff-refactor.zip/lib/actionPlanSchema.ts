import { z } from "zod"

export const ActionPlanSchema = z.object({
  id: z.string().min(3),
  findingId: z.string().min(3),
  finding: z.string().min(3), // This will be mapped to findingTitle
  businessOwner: z.string().min(2),
  auditorInCharge: z.string().min(2),
  status: z.enum(["In Progress", "Completed", "Changes Requested"]),
  progress: z.number().min(0).max(100).default(0),
  lastUpdated: z.string().optional(), // ISO date
})

export type ActionPlan = z.infer<typeof ActionPlanSchema>
