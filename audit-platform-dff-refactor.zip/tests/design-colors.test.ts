import fs from "fs"
import path from "path"

test("no yellow colors are used", () => {
  const banned = /(bg|text|border)-(yellow|amber)-\d{2,3}|#F5F7FA|#F5F7FA|#F5F7FA|rgb$$255,\s*255,\s*0$$/i
  const exts = [".tsx", ".ts", ".css", ".scss"]
  const files: string[] = []

  function walk(dir: string) {
    if (!fs.existsSync(dir)) return
    for (const f of fs.readdirSync(dir)) {
      const p = path.join(dir, f)
      const stat = fs.statSync(p)
      if (stat.isDirectory() && !f.startsWith(".") && f !== "node_modules") {
        walk(p)
      } else if (exts.includes(path.extname(p))) {
        files.push(p)
      }
    }
  }

  walk(path.join(process.cwd(), "app"))
  walk(path.join(process.cwd(), "components"))

  const offenders = files.filter((f) => {
    try {
      return banned.test(fs.readFileSync(f, "utf8"))
    } catch {
      return false
    }
  })

  expect(offenders).toHaveLength(0)
  if (offenders.length > 0) {
    throw new Error(`Remove yellow from: \n${offenders.join("\n")}`)
  }
})
