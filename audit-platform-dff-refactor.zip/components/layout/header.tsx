"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { PremiumButton } from "@/components/ui/premium-button"
import { PremiumInput } from "@/components/ui/premium-input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { PremiumCard, PremiumCardContent } from "@/components/ui/premium-card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Bell, Search, ChevronRight, Home, Briefcase, ShieldAlert, Users, FileText, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"

// Helper function to generate breadcrumbs (remains the same)
const generateBreadcrumbs = (pathname: string) => {
  const pathParts = pathname.split("/").filter((part) => part)
  const breadcrumbs = [{ href: "/", label: "Home", icon: Home, isCurrent: pathname === "/" }]

  let currentPath = ""
  pathParts.forEach((part, index) => {
    currentPath += `/${part}`
    breadcrumbs.push({
      href: currentPath,
      label: part.charAt(0).toUpperCase() + part.slice(1).replace(/-/g, " "),
      icon: null,
      isCurrent: index === pathParts.length - 1,
    })
  })
  return breadcrumbs
}

interface SearchResultItem {
  id: string
  title: string
  detail?: string
  href: string
  icon: React.ElementType
}

interface SearchResultGroup {
  category: string
  items: SearchResultItem[]
}

type SearchResults = SearchResultGroup[]

// Mock search function
const mockAllData = {
  assignments: [
    {
      id: "as1",
      title: "IT Security Compliance Check",
      detail: "Due: 2025-10-15",
      href: "/assignments/as1",
      icon: Briefcase,
    },
    {
      id: "as2",
      title: "Q3 Financial Audit",
      detail: "Status: In Progress",
      href: "/assignments/as2",
      icon: Briefcase,
    },
    {
      id: "as3",
      title: "Data Privacy Compliance Review",
      detail: "Due: 2025-11-01",
      href: "/assignments/as3",
      icon: Briefcase,
    },
  ],
  risks: [
    {
      id: "rs1",
      title: "Non-compliance with security policies",
      detail: "Severity: High",
      href: "/risks/rs1",
      icon: ShieldAlert,
    },
    {
      id: "rs2",
      title: "Data Breach Possibility",
      detail: "Severity: Critical",
      href: "/risks/rs2",
      icon: ShieldAlert,
    },
    { id: "rs3", title: "Vendor Compliance Risk", detail: "Severity: Medium", href: "/risks/rs3", icon: ShieldAlert },
  ],
  findings: [
    {
      id: "fn1",
      title: "Firewall Misconfiguration",
      detail: "Status: Open",
      href: "/findings/fn1",
      icon: AlertTriangle,
    },
    {
      id: "fn2",
      title: "Access Control Lacking for PII",
      detail: "Status: Overdue",
      href: "/findings/fn2",
      icon: AlertTriangle,
    },
  ],
  stakeholders: [
    { id: "sh1", title: "John Doe (Compliance Officer)", detail: "Internal", href: "/stakeholders/sh1", icon: Users },
    { id: "sh2", title: "External Auditors Inc.", detail: "External Partner", href: "/stakeholders/sh2", icon: Users },
  ],
  reports: [
    { id: "rp1", title: "Q2 Compliance Report", detail: "Status: Approved", href: "/reports/rp1", icon: FileText },
  ],
}

const getMockSearchResults = (query: string): SearchResults => {
  if (!query.trim()) return []
  const lowerQuery = query.toLowerCase()
  const results: SearchResults = []

  // Special case for "Compliance Check"
  if (lowerQuery.includes("compliance check")) {
    const assignment = mockAllData.assignments.find((a) => a.id === "as1")
    const risk = mockAllData.risks.find((r) => r.id === "rs1")
    if (assignment) {
      results.push({
        category: "Assignments",
        items: [assignment],
      })
    }
    if (risk) {
      results.push({
        category: "Risks",
        items: [risk],
      })
    }
    return results
  }

  const assignmentItems = mockAllData.assignments.filter(
    (item) =>
      item.title.toLowerCase().includes(lowerQuery) ||
      (typeof item.detail === "string" && item.detail.toLowerCase().includes(lowerQuery)),
  )
  if (assignmentItems.length > 0) results.push({ category: "Assignments", items: assignmentItems })

  const riskItems = mockAllData.risks.filter(
    (item) =>
      item.title.toLowerCase().includes(lowerQuery) ||
      (typeof item.detail === "string" && item.detail.toLowerCase().includes(lowerQuery)),
  )
  if (riskItems.length > 0) results.push({ category: "Risks", items: riskItems })

  const findingItems = mockAllData.findings.filter(
    (item) =>
      item.title.toLowerCase().includes(lowerQuery) ||
      (typeof item.detail === "string" && item.detail.toLowerCase().includes(lowerQuery)),
  )
  if (findingItems.length > 0) results.push({ category: "Findings", items: findingItems })

  const stakeholderItems = mockAllData.stakeholders.filter(
    (item) =>
      item.title.toLowerCase().includes(lowerQuery) ||
      (typeof item.detail === "string" && item.detail.toLowerCase().includes(lowerQuery)),
  )
  if (stakeholderItems.length > 0) results.push({ category: "Stakeholders", items: stakeholderItems })

  const reportItems = mockAllData.reports.filter(
    (item) =>
      item.title.toLowerCase().includes(lowerQuery) ||
      (typeof item.detail === "string" && item.detail.toLowerCase().includes(lowerQuery)),
  )
  if (reportItems.length > 0) results.push({ category: "Reports", items: reportItems })

  return results
}

export default function Header() {
  const pathname = usePathname()
  const breadcrumbs = generateBreadcrumbs(pathname)

  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<SearchResults>([])
  const [isResultsPanelOpen, setIsResultsPanelOpen] = useState(false)
  const searchContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (searchQuery.trim()) {
      const timer = setTimeout(() => {
        const results = getMockSearchResults(searchQuery)
        setSearchResults(results)
        setIsResultsPanelOpen(true)
      }, 300) // Debounce search
      return () => clearTimeout(timer)
    } else {
      setSearchResults([])
      setIsResultsPanelOpen(false)
    }
  }, [searchQuery])

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setIsResultsPanelOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  const isDashboardPage = pathname === "/dashboard" || pathname.startsWith("/dashboard/")

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-4 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-white/20 dark:border-white/10 shadow-lg px-4 md:px-6 shrink-0 transition-all duration-300">
      <div className="md:hidden">
        <div className="p-1 bg-white/30 dark:bg-slate-800/30 backdrop-blur-sm rounded-lg border border-white/20 dark:border-white/10 hover:bg-white/50 dark:hover:bg-slate-800/50 transition-all duration-300">
          <SidebarTrigger className="h-8 w-8 hover:text-turquoise-600 dark:hover:text-turquoise-400 transition-colors duration-300" />
        </div>
      </div>

      <nav className="hidden md:flex items-center text-sm">
        {breadcrumbs.map((crumb, index) => (
          <div key={index} className="flex items-center animate-fade-in" style={{ animationDelay: `${index * 100}ms` }}>
            {index > 0 && <ChevronRight className="h-4 w-4 mx-1.5 text-muted-foreground" />}
            {crumb.isCurrent ? (
              <span className="font-poppins font-semibold text-foreground px-2 py-1 bg-white/30 dark:bg-slate-800/30 backdrop-blur-sm rounded-lg border border-white/20 dark:border-white/10">
                {crumb.icon && index === 0 ? (
                  <span className="flex items-center gap-1.5">
                    <crumb.icon className="h-4 w-4" /> {crumb.label}
                  </span>
                ) : (
                  crumb.label
                )}
              </span>
            ) : (
              <Link
                href={crumb.href}
                className="text-muted-foreground hover:text-turquoise-600 dark:hover:text-turquoise-400 flex items-center gap-1.5 px-2 py-1 rounded-lg hover:bg-white/20 dark:hover:bg-slate-800/20 transition-all duration-300 font-medium"
              >
                {crumb.icon && index === 0 && <crumb.icon className="h-4 w-4" />}
                {crumb.label}
              </Link>
            )}
          </div>
        ))}
      </nav>

      <div className="ml-auto flex items-center gap-3">
        <div className="relative hidden md:block" ref={searchContainerRef}>
          <PremiumInput
            type="search"
            placeholder="Smart search..."
            className="w-[200px] md:w-[250px] lg:w-[300px] h-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => {
              if (searchQuery.trim()) setIsResultsPanelOpen(true)
            }}
            icon={<Search className="h-4 w-4" />}
            variant="glass"
          />
          {isResultsPanelOpen && (
            <PremiumCard
              variant="glass"
              className="absolute top-full mt-2 w-full shadow-xl z-50 border border-white/20 dark:border-white/10 animate-fade-in"
            >
              <ScrollArea className="max-h-80">
                <PremiumCardContent className="p-3">
                  {searchResults.length > 0
                    ? searchResults.map((group) => (
                        <div key={group.category} className="mb-3 last:mb-0">
                          <h4 className="text-xs font-poppins font-semibold text-muted-foreground uppercase tracking-wider px-2 pt-1 pb-2">
                            {group.category}
                          </h4>
                          <ul className="space-y-1">
                            {group.items.map((item) => (
                              <li key={item.id}>
                                <Link
                                  href={item.href}
                                  className="flex items-center gap-3 p-3 bg-white/20 dark:bg-slate-800/20 backdrop-blur-sm rounded-xl border border-white/10 dark:border-white/5 hover:bg-white/40 dark:hover:bg-slate-800/40 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 group"
                                  onClick={() => {
                                    setIsResultsPanelOpen(false)
                                    setSearchQuery("")
                                  }}
                                >
                                  <div className="flex items-center justify-center w-8 h-8 bg-gradient-to-tr from-turquoise-500 to-turquoise-600 rounded-lg text-white group-hover:scale-110 transition-transform duration-300">
                                    <item.icon className="h-4 w-4" />
                                  </div>
                                  <div className="flex-grow overflow-hidden">
                                    <p className="font-poppins font-medium text-sm truncate text-foreground group-hover:text-turquoise-600 dark:group-hover:text-turquoise-400 transition-colors duration-300">
                                      {item.title}
                                    </p>
                                    {item.detail && (
                                      <p className="text-xs text-muted-foreground truncate">{item.detail}</p>
                                    )}
                                  </div>
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))
                    : searchQuery.trim() && (
                        <p className="p-4 text-sm text-muted-foreground text-center font-poppins">
                          No results found for "{searchQuery}"
                        </p>
                      )}
                </PremiumCardContent>
              </ScrollArea>
            </PremiumCard>
          )}
        </div>

        <div className="relative">
          <PremiumButton variant="glass" size="icon" className="relative rounded-full h-10 w-10">
            <Bell className="h-5 w-5" />
            <span className="absolute top-1.5 right-1.5 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-turquoise-500 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-turquoise-500 shadow-lg shadow-turquoise-500/50"></span>
            </span>
            <span className="sr-only">Notifications</span>
          </PremiumButton>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="relative h-10 w-10 rounded-full p-0 ring-2 ring-white/20 dark:ring-white/10 hover:ring-turquoise-500/30 transition-all duration-300 hover:scale-110 group">
              <Avatar className="h-10 w-10">
                <AvatarImage src="/placeholder.svg?width=40&height=40" alt="User Profile" />
                <AvatarFallback className="bg-gradient-to-tr from-turquoise-500 to-turquoise-600 text-white font-poppins font-semibold">
                  UA
                </AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white dark:border-slate-900 shadow-lg shadow-emerald-500/50 group-hover:scale-110 transition-transform duration-300" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            align="end"
            className="w-64 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-white/20 dark:border-white/10 shadow-xl"
          >
            <DropdownMenuLabel className="p-4">
              <div className="flex items-center gap-3">
                <Avatar className="h-12 w-12">
                  <AvatarImage src="/placeholder.svg?width=48&height=48" alt="User Profile" />
                  <AvatarFallback className="bg-gradient-to-tr from-turquoise-500 to-turquoise-600 text-white font-poppins font-semibold">
                    UA
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-poppins font-semibold text-foreground">John Doe</p>
                  <p className="text-sm text-muted-foreground">audit.manager@example.com</p>
                </div>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator className="bg-white/20 dark:bg-white/10" />
            <DropdownMenuItem className="font-medium hover:bg-turquoise-50 dark:hover:bg-turquoise-950 hover:text-turquoise-700 dark:hover:text-turquoise-300">
              Profile
            </DropdownMenuItem>
            <DropdownMenuItem className="font-medium hover:bg-turquoise-50 dark:hover:bg-turquoise-950 hover:text-turquoise-700 dark:hover:text-turquoise-300">
              Settings
            </DropdownMenuItem>
            <DropdownMenuItem className="font-medium hover:bg-turquoise-50 dark:hover:bg-turquoise-950 hover:text-turquoise-700 dark:hover:text-turquoise-300">
              Support
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-white/20 dark:bg-white/10" />
            <DropdownMenuItem className="font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950">
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
