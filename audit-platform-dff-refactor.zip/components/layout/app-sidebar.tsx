"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"
import { Sidebar, SidebarHeader, SidebarContent, SidebarFooter, useSidebar } from "@/components/ui/sidebar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import ThemeToggle from "@/components/theme-toggle"
import LanguageSwitcher from "@/components/language-switcher"
import { PremiumInput } from "@/components/ui/premium-input"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  FileText,
  ShieldAlert,
  ClipboardList,
  ClipboardCheck,
  ListChecks,
  BarChart3,
  Settings,
  BuildingIcon,
  Users,
  Briefcase,
  ShieldCheck,
  Archive,
  MapIcon as Sitemap,
  Gauge,
  History,
  CheckSquare,
  BookHeart,
  BarChartHorizontalBig,
  Search,
  ChevronDown,
} from "lucide-react"
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const menuGroups = [
  {
    title: "Main",
    items: [{ href: "/dashboard", label: "Dashboard", icon: LayoutDashboard }],
  },
  {
    title: "Audit Cycle",
    items: [
      { href: "/audit-plans", label: "Audit Plans", icon: FileText },
      { href: "/engagements", label: "Engagements", icon: Briefcase },
      { href: "/assignments", label: "Assignments", icon: ClipboardList },
      { href: "/findings", label: "Findings", icon: ClipboardCheck },
      { href: "/action-plans", label: "Action Plans", icon: ListChecks },
    ],
  },
  {
    title: "Governance",
    items: [
      { href: "/risks", label: "Risks", icon: ShieldAlert },
      { href: "/controls", label: "Controls", icon: ShieldCheck },
      { href: "/audit-universe", label: "Audit Universe", icon: Sitemap },
    ],
  },
  {
    title: "Analytics & Reporting",
    items: [
      { href: "/reports", label: "Reports", icon: BarChart3 },
      { href: "/executive-command-center", label: "Executive Command Center", icon: Gauge },
      { href: "/data-analytics-hub", label: "Analytics Hub", icon: BarChartHorizontalBig },
    ],
  },
  {
    title: "Resources",
    items: [
      { href: "/stakeholders", label: "Stakeholders", icon: Users },
      { href: "/evidence-locker", label: "Evidence Locker", icon: Archive },
      { href: "/knowledge-center", label: "Knowledge Center", icon: BookHeart },
    ],
  },
  {
    title: "System",
    items: [
      { href: "/global-activity-log", label: "Global Activity Log", icon: History },
      { href: "/quality-assurance-reviews", label: "Quality Assurance", icon: CheckSquare },
      { href: "/settings", label: "Settings", icon: Settings },
    ],
  },
]

export default function AppSidebar() {
  const pathname = usePathname()
  const { state, isMobile } = useSidebar()
  const [searchTerm, setSearchTerm] = useState("")

  const filteredMenuGroups = menuGroups
    .map((group) => ({
      ...group,
      items: group.items.filter((item) => item.label.toLowerCase().includes(searchTerm.toLowerCase())),
    }))
    .filter((group) => group.items.length > 0)

  const defaultOpen = menuGroups.findIndex((group) => group.items.some((item) => pathname.startsWith(item.href)))

  return (
    <TooltipProvider>
      <Sidebar
        collapsible="icon"
        side="left"
        variant="sidebar"
        className="flex flex-col bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-r border-white/20 dark:border-white/10 shadow-xl transition-all duration-300"
      >
        <SidebarHeader className="p-4 flex items-center gap-2.5 border-b border-white/10 dark:border-white/5">
          <Link href="/dashboard" className="flex items-center gap-2.5 group">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-tr from-turquoise-500 to-turquoise-600 rounded-xl blur-lg opacity-30 group-hover:opacity-50 transition-opacity duration-300" />
              <div className="relative w-8 h-8 bg-gradient-to-tr from-turquoise-500 to-turquoise-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-turquoise-500/50 transition-all duration-300 group-hover:scale-110">
                <BuildingIcon className="w-5 h-5 text-white" />
              </div>
            </div>
            {state === "expanded" && (
              <h1 className="text-xl font-poppins font-bold bg-gradient-to-r from-navy-900 to-turquoise-600 bg-clip-text text-transparent whitespace-nowrap group-hover:from-turquoise-600 group-hover:to-navy-900 transition-all duration-300">
                Audit Platform
              </h1>
            )}
          </Link>
        </SidebarHeader>

        {state === "expanded" && (
          <div className="px-4 mb-4 animate-fade-in">
            <PremiumInput
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              icon={<Search className="h-4 w-4" />}
              variant="glass"
              className="w-full"
            />
          </div>
        )}

        <SidebarContent className="flex-1 overflow-y-auto">
          {state === "expanded" ? (
            <Accordion
              type="single"
              collapsible
              defaultValue={`item-${defaultOpen > -1 ? defaultOpen : 0}`}
              className="w-full px-2 space-y-2"
            >
              {filteredMenuGroups.map((group, groupIndex) => (
                <AccordionItem
                  value={`item-${groupIndex}`}
                  key={group.title}
                  className="border-0 bg-white/20 dark:bg-slate-800/20 backdrop-blur-sm rounded-xl border border-white/10 dark:border-white/5 shadow-lg hover:bg-white/30 dark:hover:bg-slate-800/30 transition-all duration-300"
                >
                  <AccordionTrigger className="py-3 px-4 text-sm font-poppins font-semibold text-foreground hover:no-underline rounded-xl group [&[data-state=open]>svg]:rotate-180">
                    <span className="uppercase tracking-wide">{group.title}</span>
                    <ChevronDown className="h-4 w-4 shrink-0 transition-transform duration-300 group-hover:text-turquoise-500" />
                  </AccordionTrigger>
                  <AccordionContent className="pt-1 pb-3 px-2">
                    <div className="flex flex-col space-y-1">
                      {group.items.map((item, itemIndex) => {
                        const isActive = pathname.startsWith(item.href)
                        return (
                          <Link
                            key={item.href}
                            href={item.href}
                            className={cn(
                              "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-300 group relative overflow-hidden",
                              "hover:bg-white/40 dark:hover:bg-slate-800/40 hover:shadow-lg hover:-translate-y-0.5",
                              isActive
                                ? "bg-gradient-to-r from-turquoise-500/20 to-turquoise-600/20 text-turquoise-700 dark:text-turquoise-300 shadow-lg shadow-turquoise-500/20"
                                : "text-foreground hover:text-turquoise-600 dark:hover:text-turquoise-400",
                            )}
                            style={{ animationDelay: `${itemIndex * 50}ms` }}
                          >
                            {isActive && (
                              <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-turquoise-500 to-turquoise-600 rounded-r-full shadow-lg shadow-turquoise-500/50 animate-glow" />
                            )}
                            <div
                              className={cn(
                                "relative flex items-center justify-center w-5 h-5 transition-all duration-300",
                                isActive && "text-turquoise-600 dark:text-turquoise-400",
                              )}
                            >
                              <item.icon className="h-5 w-5 group-hover:scale-110 transition-transform duration-300" />
                            </div>
                            <span className="truncate group-hover:text-turquoise-600 dark:group-hover:text-turquoise-400 transition-colors duration-300">
                              {item.label}
                            </span>
                          </Link>
                        )
                      })}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          ) : (
            /* Collapsed state with gradient icon circles and enhanced tooltips */
            <div className="flex flex-col items-center space-y-3 px-2 py-4">
              {menuGroups
                .flatMap((group) => group.items)
                .map((item, index) => {
                  const isActive = pathname.startsWith(item.href)
                  return (
                    <Tooltip key={item.href}>
                      <TooltipTrigger asChild>
                        <Link
                          href={item.href}
                          className={cn(
                            "relative flex items-center justify-center w-12 h-12 rounded-xl transition-all duration-300 group overflow-hidden",
                            "hover:shadow-lg hover:-translate-y-1 hover:scale-110",
                            isActive
                              ? "bg-gradient-to-tr from-turquoise-500 to-turquoise-600 text-white shadow-lg shadow-turquoise-500/50"
                              : "bg-white/20 dark:bg-slate-800/20 backdrop-blur-sm border border-white/20 dark:border-white/10 text-foreground hover:bg-white/40 dark:hover:bg-slate-800/40 hover:text-turquoise-600 dark:hover:text-turquoise-400",
                          )}
                          style={{ animationDelay: `${index * 50}ms` }}
                        >
                          {isActive && (
                            <div className="absolute inset-0 bg-gradient-to-tr from-turquoise-500 to-turquoise-600 animate-pulse opacity-20" />
                          )}
                          <item.icon className="h-5 w-5 relative z-10 group-hover:scale-110 transition-transform duration-300" />
                          {isActive && (
                            <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-tr from-turquoise-400 to-turquoise-500 rounded-full shadow-lg shadow-turquoise-500/50 animate-ping" />
                          )}
                        </Link>
                      </TooltipTrigger>
                      <TooltipContent
                        side="right"
                        align="center"
                        className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-white/20 dark:border-white/10 shadow-xl"
                      >
                        <span className="font-poppins font-medium">{item.label}</span>
                      </TooltipContent>
                    </Tooltip>
                  )
                })}
            </div>
          )}
        </SidebarContent>

        <SidebarFooter className="p-4 space-y-4 mt-auto border-t border-white/10 dark:border-white/5 bg-white/40 dark:bg-slate-800/40 backdrop-blur-sm">
          {state === "expanded" && (
            <div className="flex items-center gap-3 px-2 py-2 bg-white/30 dark:bg-slate-800/30 backdrop-blur-sm rounded-xl border border-white/20 dark:border-white/10 hover:bg-white/50 dark:hover:bg-slate-800/50 transition-all duration-300 group animate-fade-in">
              <div className="relative">
                <Avatar className="h-10 w-10 ring-2 ring-white/20 dark:ring-white/10 group-hover:ring-turquoise-500/30 transition-all duration-300">
                  <AvatarImage src="/placeholder.svg?width=40&height=40" alt="User Name" />
                  <AvatarFallback className="bg-gradient-to-tr from-turquoise-500 to-turquoise-600 text-white font-poppins font-semibold">
                    JD
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white dark:border-slate-900 shadow-lg shadow-emerald-500/50" />
              </div>
              <div>
                <p className="text-sm font-poppins font-semibold text-foreground">John Doe</p>
                <p className="text-xs text-muted-foreground">Audit Manager</p>
              </div>
            </div>
          )}
          {state === "collapsed" && !isMobile && (
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="relative mx-auto cursor-pointer group">
                  <Avatar className="h-10 w-10 ring-2 ring-white/20 dark:ring-white/10 group-hover:ring-turquoise-500/30 transition-all duration-300 group-hover:scale-110">
                    <AvatarImage src="/placeholder.svg?width=40&height=40" alt="User Name" />
                    <AvatarFallback className="bg-gradient-to-tr from-turquoise-500 to-turquoise-600 text-white font-poppins font-semibold">
                      JD
                    </AvatarFallback>
                  </Avatar>
                  <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white dark:border-slate-900 shadow-lg shadow-emerald-500/50" />
                </div>
              </TooltipTrigger>
              <TooltipContent
                side="right"
                align="center"
                className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-white/20 dark:border-white/10 shadow-xl"
              >
                <p className="font-poppins font-semibold">John Doe</p>
                <p className="text-xs text-muted-foreground">Audit Manager</p>
              </TooltipContent>
            </Tooltip>
          )}

          <div
            className={cn(
              "flex items-center transition-all duration-300",
              state === "expanded" ? "justify-between" : "justify-center flex-col gap-3",
            )}
          >
            <div
              className={cn(
                "p-2 bg-white/30 dark:bg-slate-800/30 backdrop-blur-sm rounded-xl border border-white/20 dark:border-white/10 hover:bg-white/50 dark:hover:bg-slate-800/50 transition-all duration-300",
                state === "collapsed" && "hover:scale-110",
              )}
            >
              <ThemeToggle />
            </div>
            <div
              className={cn(
                "p-2 bg-white/30 dark:bg-slate-800/30 backdrop-blur-sm rounded-xl border border-white/20 dark:border-white/10 hover:bg-white/50 dark:hover:bg-slate-800/50 transition-all duration-300",
                state === "collapsed" && "hover:scale-110",
              )}
            >
              <LanguageSwitcher />
            </div>
          </div>
          {state === "expanded" && (
            <p className="text-xs text-muted-foreground text-center pt-2 font-poppins animate-fade-in">Version 1.0.0</p>
          )}
        </SidebarFooter>
      </Sidebar>
    </TooltipProvider>
  )
}
