import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const premiumCardVariants = cva(
  "relative overflow-hidden rounded-2xl shadow-lg backdrop-blur-md border transition-all duration-300 hover:shadow-xl hover:-translate-y-1",
  {
    variants: {
      variant: {
        glass: "bg-white/70 dark:bg-slate-900/70 border-white/20 dark:border-white/10",
        solid: "bg-card border-border shadow-md",
        gradient: "bg-gradient-to-br from-turquoise-500 to-turquoise-600 text-white border-turquoise-400",
        navy: "bg-gradient-to-br from-navy-800 to-navy-900 text-white border-navy-700",
      },
      size: {
        sm: "p-4",
        default: "p-6",
        lg: "p-8",
      },
    },
    defaultVariants: {
      variant: "glass",
      size: "default",
    },
  },
)

export interface PremiumCardProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof premiumCardVariants> {
  icon?: React.ReactNode
  iconVariant?: "gradient" | "solid" | "outline"
}

const PremiumCard = React.forwardRef<HTMLDivElement, PremiumCardProps>(
  ({ className, variant, size, icon, iconVariant = "gradient", children, ...props }, ref) => (
    <div ref={ref} className={cn(premiumCardVariants({ variant, size }), className)} {...props}>
      {children}
      {icon && (
        <div
          className={cn(
            "absolute right-4 top-4 h-10 w-10 flex items-center justify-center rounded-full shadow-md transition-transform duration-300 hover:scale-110",
            {
              "bg-gradient-to-tr from-turquoise-400 to-turquoise-600 text-white": iconVariant === "gradient",
              "bg-primary text-primary-foreground": iconVariant === "solid",
              "border-2 border-primary text-primary bg-background": iconVariant === "outline",
            },
          )}
        >
          {icon}
        </div>
      )}
    </div>
  ),
)
PremiumCard.displayName = "PremiumCard"

const PremiumCardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex flex-col space-y-2 mb-4", className)} {...props} />
  ),
)
PremiumCardHeader.displayName = "PremiumCardHeader"

const PremiumCardTitle = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        "text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide font-poppins",
        className,
      )}
      {...props}
    />
  ),
)
PremiumCardTitle.displayName = "PremiumCardTitle"

const PremiumCardValue = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn("text-4xl font-bold text-slate-900 dark:text-white font-poppins", className)}
      {...props}
    />
  ),
)
PremiumCardValue.displayName = "PremiumCardValue"

const PremiumCardContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => <div ref={ref} className={cn("space-y-2", className)} {...props} />,
)
PremiumCardContent.displayName = "PremiumCardContent"

export { PremiumCard, PremiumCardHeader, PremiumCardTitle, PremiumCardValue, PremiumCardContent, premiumCardVariants }
