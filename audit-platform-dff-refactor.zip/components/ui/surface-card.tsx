import { cn } from "@/lib/utils"
import type React from "react"

export interface SurfaceCardProps {
  children: React.ReactNode
  className?: string
}

export function SurfaceCard({ children, className }: SurfaceCardProps) {
  return (
    <div
      className={cn(
        "rounded-2xl bg-white shadow-card border border-dff-line/60 backdrop-blur-sm",
        "transition-all duration-200 ease-soft hover:shadow-hover",
        "dark:bg-slate-900 dark:border-slate-700",
        className,
      )}
    >
      {children}
    </div>
  )
}
