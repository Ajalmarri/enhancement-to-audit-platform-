import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const premiumInputVariants = cva(
  "flex w-full rounded-xl border bg-background px-4 py-3 text-sm font-inter transition-all duration-300 file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50",
  {
    variants: {
      variant: {
        default:
          "border-input focus-visible:ring-2 focus-visible:ring-turquoise-500 focus-visible:border-turquoise-500 focus-visible:shadow-lg focus-visible:shadow-turquoise-500/20",
        glass:
          "bg-white/20 backdrop-blur-md border-white/30 focus-visible:bg-white/30 focus-visible:border-white/50 focus-visible:shadow-lg",
        filled:
          "bg-slate-50 dark:bg-slate-800 border-transparent focus-visible:bg-white dark:focus-visible:bg-slate-700 focus-visible:ring-2 focus-visible:ring-turquoise-500 focus-visible:shadow-lg",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
)

export interface PremiumInputProps
  extends React.InputHTMLAttributes<HTMLInputElement>,
    VariantProps<typeof premiumInputVariants> {
  icon?: React.ReactNode
  iconPosition?: "left" | "right"
}

const PremiumInput = React.forwardRef<HTMLInputElement, PremiumInputProps>(
  ({ className, variant, type, icon, iconPosition = "left", ...props }, ref) => {
    if (icon) {
      return (
        <div className="relative">
          {iconPosition === "left" && (
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">{icon}</div>
          )}
          <input
            type={type}
            className={cn(
              premiumInputVariants({ variant }),
              {
                "pl-10": iconPosition === "left",
                "pr-10": iconPosition === "right",
              },
              className,
            )}
            ref={ref}
            {...props}
          />
          {iconPosition === "right" && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">{icon}</div>
          )}
        </div>
      )
    }

    return <input type={type} className={cn(premiumInputVariants({ variant }), className)} ref={ref} {...props} />
  },
)
PremiumInput.displayName = "PremiumInput"

export { PremiumInput, premiumInputVariants }
