import * as React from "react"
import { PremiumCard, PremiumCardHeader, PremiumCardTitle, PremiumCardValue, PremiumCardContent } from "./premium-card"
import { cn } from "@/lib/utils"

interface MetricCardProps {
  title: string
  value: string | number
  icon?: React.ReactNode
  trend?: {
    value: number
    label: string
    isPositive?: boolean
  }
  className?: string
  variant?: "glass" | "solid" | "gradient" | "navy"
}

const MetricCard = React.forwardRef<HTMLDivElement, MetricCardProps>(
  ({ title, value, icon, trend, className, variant = "glass", ...props }, ref) => (
    <PremiumCard
      ref={ref}
      variant={variant}
      icon={icon}
      className={cn("group hover:scale-[1.02] transition-transform duration-300", className)}
      {...props}
    >
      <PremiumCardHeader>
        <PremiumCardTitle>{title}</PremiumCardTitle>
        <PremiumCardValue>{value}</PremiumCardValue>
      </PremiumCardHeader>
      {trend && (
        <PremiumCardContent>
          <div className="flex items-center gap-2 text-sm">
            <span
              className={cn(
                "flex items-center gap-1 font-medium",
                trend.isPositive !== false
                  ? "text-emerald-600 dark:text-emerald-400"
                  : "text-red-600 dark:text-red-400",
              )}
            >
              {trend.isPositive !== false ? "↗" : "↘"}
              {Math.abs(trend.value)}%
            </span>
            <span className="text-muted-foreground">{trend.label}</span>
          </div>
        </PremiumCardContent>
      )}
    </PremiumCard>
  ),
)
MetricCard.displayName = "MetricCard"

export { MetricCard }
