import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const premiumTableVariants = cva("w-full caption-bottom text-sm font-inter", {
  variants: {
    variant: {
      default: "bg-transparent",
      glass:
        "bg-white/40 dark:bg-slate-900/40 backdrop-blur-md rounded-2xl border border-white/20 dark:border-white/10 shadow-lg overflow-hidden",
      solid: "bg-card rounded-2xl border shadow-lg overflow-hidden",
    },
  },
  defaultVariants: {
    variant: "glass",
  },
})

const PremiumTable = React.forwardRef<
  HTMLTableElement,
  React.HTMLAttributes<HTMLTableElement> & VariantProps<typeof premiumTableVariants>
>(({ className, variant, ...props }, ref) => (
  <div className="relative w-full overflow-auto">
    <table ref={ref} className={cn(premiumTableVariants({ variant }), className)} {...props} />
  </div>
))
PremiumTable.displayName = "PremiumTable"

const PremiumTableHeader = React.forwardRef<HTMLTableSectionElement, React.HTMLAttributes<HTMLTableSectionElement>>(
  ({ className, ...props }, ref) => (
    <thead
      ref={ref}
      className={cn(
        "sticky top-0 z-10 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-white/20 dark:border-white/10 shadow-sm [&_tr]:border-0",
        className,
      )}
      {...props}
    />
  ),
)
PremiumTableHeader.displayName = "PremiumTableHeader"

const PremiumTableBody = React.forwardRef<HTMLTableSectionElement, React.HTMLAttributes<HTMLTableSectionElement>>(
  ({ className, ...props }, ref) => (
    <tbody ref={ref} className={cn("[&_tr:last-child]:border-0", className)} {...props} />
  ),
)
PremiumTableBody.displayName = "PremiumTableBody"

const PremiumTableFooter = React.forwardRef<HTMLTableSectionElement, React.HTMLAttributes<HTMLTableSectionElement>>(
  ({ className, ...props }, ref) => (
    <tfoot
      ref={ref}
      className={cn(
        "border-t border-white/20 dark:border-white/10 bg-white/60 dark:bg-slate-900/60 backdrop-blur-md font-medium [&>tr]:last:border-b-0",
        className,
      )}
      {...props}
    />
  ),
)
PremiumTableFooter.displayName = "PremiumTableFooter"

const PremiumTableRow = React.forwardRef<
  HTMLTableRowElement,
  React.HTMLAttributes<HTMLTableRowElement> & {
    striped?: boolean
  }
>(({ className, striped = true, ...props }, ref) => (
  <tr
    ref={ref}
    className={cn(
      "border-b border-white/10 dark:border-white/5 transition-all duration-300 hover:bg-white/60 dark:hover:bg-slate-800/60 hover:shadow-lg hover:shadow-turquoise-500/10 hover:-translate-y-0.5 data-[state=selected]:bg-turquoise-50 dark:data-[state=selected]:bg-turquoise-950 rounded-lg",
      striped && "even:bg-white/20 dark:even:bg-slate-800/20",
      className,
    )}
    {...props}
  />
))
PremiumTableRow.displayName = "PremiumTableRow"

const PremiumTableHead = React.forwardRef<HTMLTableCellElement, React.ThHTMLAttributes<HTMLTableCellElement>>(
  ({ className, ...props }, ref) => (
    <th
      ref={ref}
      className={cn(
        "h-14 px-6 text-left align-middle font-poppins font-semibold text-sm text-slate-600 dark:text-slate-300 uppercase tracking-wide [&:has([role=checkbox])]:pr-0",
        className,
      )}
      {...props}
    />
  ),
)
PremiumTableHead.displayName = "PremiumTableHead"

const PremiumTableCell = React.forwardRef<HTMLTableCellElement, React.TdHTMLAttributes<HTMLTableCellElement>>(
  ({ className, ...props }, ref) => (
    <td
      ref={ref}
      className={cn("px-6 py-4 align-middle font-medium [&:has([role=checkbox])]:pr-0", className)}
      {...props}
    />
  ),
)
PremiumTableCell.displayName = "PremiumTableCell"

const PremiumTableCaption = React.forwardRef<HTMLTableCaptionElement, React.HTMLAttributes<HTMLTableCaptionElement>>(
  ({ className, ...props }, ref) => (
    <caption ref={ref} className={cn("mt-6 text-sm text-muted-foreground font-poppins", className)} {...props} />
  ),
)
PremiumTableCaption.displayName = "PremiumTableCaption"

export {
  PremiumTable,
  PremiumTableHeader,
  PremiumTableBody,
  PremiumTableFooter,
  PremiumTableHead,
  PremiumTableRow,
  PremiumTableCell,
  PremiumTableCaption,
  premiumTableVariants,
}
