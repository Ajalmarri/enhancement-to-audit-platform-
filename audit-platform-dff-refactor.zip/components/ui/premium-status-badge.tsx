import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"
import { AlertTriangle, ShieldCheck, CheckCircle, XCircle, Clock, Play, Info } from "lucide-react"

const statusBadgeVariants = cva(
  "inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-semibold font-poppins transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 shadow-md hover:shadow-lg hover:-translate-y-0.5",
  {
    variants: {
      status: {
        // Risk statuses
        open: "bg-gradient-to-r from-slate-500 to-slate-600 text-white shadow-slate-500/30 hover:shadow-slate-500/50",
        mitigated: "bg-gradient-to-r from-blue-500 to-cyan-500 text-white shadow-blue-500/30 hover:shadow-blue-500/50",
        accepted:
          "bg-gradient-to-r from-emerald-500 to-green-500 text-white shadow-emerald-500/30 hover:shadow-emerald-500/50",
        closed: "bg-gradient-to-r from-slate-500 to-slate-600 text-white shadow-slate-500/30 hover:shadow-slate-500/50",

        // Action plan statuses
        "in-progress":
          "bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-blue-500/30 hover:shadow-blue-500/50",
        completed:
          "bg-gradient-to-r from-emerald-500 to-green-500 text-white shadow-emerald-500/30 hover:shadow-emerald-500/50",
        "changes-requested":
          "bg-gradient-to-r from-slate-500 to-slate-600 text-white shadow-slate-500/30 hover:shadow-slate-500/50",
        pending:
          "bg-gradient-to-r from-slate-400 to-slate-500 text-white shadow-slate-400/30 hover:shadow-slate-400/50",
        overdue:
          "bg-gradient-to-r from-red-500 to-rose-500 text-white shadow-red-500/30 hover:shadow-red-500/50 animate-pulse",

        // Finding statuses
        "pending-verification":
          "bg-gradient-to-r from-purple-500 to-violet-500 text-white shadow-purple-500/30 hover:shadow-purple-500/50",
        resolved:
          "bg-gradient-to-r from-emerald-500 to-green-500 text-white shadow-emerald-500/30 hover:shadow-emerald-500/50",
        "sent-to-business-owner":
          "bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-cyan-500/30 hover:shadow-cyan-500/50",
        "in-remediation":
          "bg-gradient-to-r from-indigo-500 to-purple-500 text-white shadow-indigo-500/30 hover:shadow-indigo-500/50",
        "action-plan-submitted":
          "bg-gradient-to-r from-teal-500 to-cyan-500 text-white shadow-teal-500/30 hover:shadow-teal-500/50",

        // Risk ratings
        low: "bg-gradient-to-r from-emerald-500 to-green-500 text-white shadow-emerald-500/30 hover:shadow-emerald-500/50",
        medium: "bg-gradient-to-r from-slate-500 to-slate-600 text-white shadow-slate-500/30 hover:shadow-slate-500/50",
        high: "bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-orange-500/30 hover:shadow-orange-500/50",
        critical:
          "bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-red-600/30 hover:shadow-red-600/50 animate-pulse",
      },
      size: {
        sm: "px-2 py-1 text-xs",
        default: "px-3 py-1.5 text-xs",
        lg: "px-4 py-2 text-sm",
      },
    },
    defaultVariants: {
      status: "pending",
      size: "default",
    },
  },
)

const statusIcons = {
  // Risk statuses
  open: AlertTriangle,
  mitigated: ShieldCheck,
  accepted: CheckCircle,
  closed: XCircle,

  // Action plan statuses
  "in-progress": Play,
  completed: CheckCircle,
  "changes-requested": AlertTriangle,
  pending: Clock,
  overdue: AlertTriangle,

  // Finding statuses
  "pending-verification": Clock,
  resolved: CheckCircle,
  "sent-to-business-owner": Info,
  "in-remediation": Play,
  "action-plan-submitted": CheckCircle,

  // Risk ratings
  low: CheckCircle,
  medium: AlertTriangle,
  high: AlertTriangle,
  critical: AlertTriangle,
}

export interface PremiumStatusBadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof statusBadgeVariants> {
  animated?: boolean
  showIcon?: boolean
}

const PremiumStatusBadge = React.forwardRef<HTMLDivElement, PremiumStatusBadgeProps>(
  ({ className, status, size, animated = false, showIcon = true, children, ...props }, ref) => {
    const IconComponent = status ? statusIcons[status] : Clock

    return (
      <div
        className={cn(statusBadgeVariants({ status, size }), animated && "animate-pulse", className)}
        ref={ref}
        {...props}
      >
        {showIcon && IconComponent && <IconComponent className="h-3 w-3 flex-shrink-0" />}
        {children}
      </div>
    )
  },
)
PremiumStatusBadge.displayName = "PremiumStatusBadge"

export { PremiumStatusBadge, statusBadgeVariants }
