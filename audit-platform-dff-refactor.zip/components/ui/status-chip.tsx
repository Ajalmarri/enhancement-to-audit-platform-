import type React from "react"
import { cn } from "@/lib/utils"

interface StatusChipProps {
  type: "inProgress" | "dueSoon" | "completed" | "changesRequested"
  children: React.ReactNode
  className?: string
}

const statusStyles = {
  inProgress: "bg-gradient-to-r from-dff-teal to-dff-tealSoft text-white",
  dueSoon: "bg-slate-100 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-300",
  completed: "bg-dff-success/10 text-dff-success border border-dff-success/20",
  changesRequested: "bg-red-50 text-red-700 border border-red-200 dark:bg-red-900/20 dark:text-red-300",
}

export function StatusChip({ type, children, className }: StatusChipProps) {
  return (
    <span
      className={cn(
        "px-2.5 py-1 rounded-full text-xs font-medium transition-all duration-200",
        statusStyles[type],
        className,
      )}
    >
      {children}
    </span>
  )
}
