import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const premiumBadgeVariants = cva(
  "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold font-poppins transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        success: "bg-gradient-to-r from-emerald-500 to-green-500 text-white shadow-md hover:shadow-lg",
        warning: "bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-md hover:shadow-lg",
        danger: "bg-gradient-to-r from-red-500 to-rose-500 text-white shadow-md hover:shadow-lg",
        info: "bg-gradient-to-r from-blue-500 to-cyan-500 text-white shadow-md hover:shadow-lg",
        turquoise: "bg-gradient-to-r from-turquoise-500 to-turquoise-600 text-white shadow-md hover:shadow-lg",
        navy: "bg-gradient-to-r from-navy-800 to-navy-900 text-white shadow-md hover:shadow-lg",
        glass: "bg-white/20 backdrop-blur-md border border-white/30 text-foreground shadow-md hover:bg-white/30",
        outline: "border-2 border-current bg-transparent",
      },
      size: {
        sm: "px-2 py-0.5 text-xs",
        default: "px-3 py-1 text-xs",
        lg: "px-4 py-1.5 text-sm",
      },
      animated: {
        true: "animate-pulse",
        false: "",
      },
    },
    defaultVariants: {
      variant: "turquoise",
      size: "default",
      animated: false,
    },
  },
)

export interface PremiumBadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof premiumBadgeVariants> {
  icon?: React.ReactNode
  pulse?: boolean
}

const PremiumBadge = React.forwardRef<HTMLDivElement, PremiumBadgeProps>(
  ({ className, variant, size, animated, icon, pulse = false, children, ...props }, ref) => (
    <div
      className={cn(premiumBadgeVariants({ variant, size, animated: animated || pulse }), className)}
      ref={ref}
      {...props}
    >
      {icon && <span className="flex-shrink-0">{icon}</span>}
      {children}
      {pulse && <div className="flex-shrink-0 w-2 h-2 bg-current rounded-full animate-ping" />}
    </div>
  ),
)
PremiumBadge.displayName = "PremiumBadge"

export { PremiumBadge, premiumBadgeVariants }
