"use client"
import { Moon, Sun, Palette } from "lucide-react"
import { useTheme } from "next-themes"
import { useState, useEffect } from "react"
import { useSidebar } from "@/components/ui/sidebar"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import { TooltipProvider } from "@/components/ui/tooltip"
import { cn } from "@/lib/utils"

export default function ThemeToggle() {
  const { setTheme, theme, resolvedTheme } = useTheme()
  const { state, isMobile } = useSidebar()
  const [mounted, setMounted] = useState(false)
  const [isAnimating, setIsAnimating] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const toggleTheme = () => {
    setIsAnimating(true)

    // Add smooth transition effect to body
    document.documentElement.style.transition = "background-color 0.3s ease, color 0.3s ease"

    setTimeout(() => {
      setTheme(theme === "light" ? "dark" : "light")
      setIsAnimating(false)

      // Remove transition after animation completes
      setTimeout(() => {
        document.documentElement.style.transition = ""
      }, 300)
    }, 150)
  }

  if (!mounted) {
    return (
      <div className="h-9 w-9 bg-white/20 dark:bg-slate-800/20 backdrop-blur-sm rounded-xl border border-white/20 dark:border-white/10 animate-pulse" />
    )
  }

  const isDark = resolvedTheme === "dark"

  const buttonContent = (
    <div className="relative flex items-center justify-center">
      <div className="relative w-5 h-5 flex items-center justify-center">
        <Sun
          className={cn(
            "absolute h-5 w-5 transition-all duration-500 ease-in-out",
            isDark ? "rotate-90 scale-0 opacity-0" : "rotate-0 scale-100 opacity-100 text-dff-warning drop-shadow-lg",
          )}
        />
        <Moon
          className={cn(
            "absolute h-5 w-5 transition-all duration-500 ease-in-out",
            isDark ? "rotate-0 scale-100 opacity-100 text-blue-400 drop-shadow-lg" : "-rotate-90 scale-0 opacity-0",
          )}
        />

        <div
          className={cn(
            "absolute inset-0 rounded-full transition-all duration-500 ease-in-out blur-md",
            isDark ? "bg-blue-400/30 scale-150" : "bg-slate-50/30 scale-150",
            isAnimating && "animate-pulse",
          )}
        />
      </div>

      {state === "expanded" && (
        <span className="ml-3 font-poppins font-medium transition-all duration-300">
          {isDark ? "Light Mode" : "Dark Mode"}
        </span>
      )}
    </div>
  )

  if (state === "collapsed" && !isMobile) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={toggleTheme}
              className={cn(
                "relative h-9 w-9 rounded-xl transition-all duration-300 group overflow-hidden",
                "bg-white/20 dark:bg-slate-800/20 backdrop-blur-sm border border-white/20 dark:border-white/10",
                "hover:bg-white/40 dark:hover:bg-slate-800/40 hover:shadow-lg hover:scale-110",
                "focus:outline-none focus:ring-2 focus:ring-turquoise-500/50 focus:ring-offset-2 focus:ring-offset-transparent",
                isAnimating && "animate-pulse",
              )}
              aria-label="Toggle theme"
            >
              <div
                className={cn(
                  "absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-300",
                  isDark
                    ? "bg-gradient-to-tr from-blue-500 to-cyan-500"
                    : "bg-gradient-to-tr from-amber-500 to-orange-500",
                )}
              />
              <div className="relative z-10 flex items-center justify-center h-full">{buttonContent}</div>
            </button>
          </TooltipTrigger>
          <TooltipContent
            side="right"
            align="center"
            className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-white/20 dark:border-white/10 shadow-xl"
          >
            <div className="flex items-center gap-2">
              <Palette className="h-4 w-4 text-turquoise-500" />
              <span className="font-poppins font-medium">Switch to {isDark ? "Light" : "Dark"} Mode</span>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  }

  return (
    <button
      onClick={toggleTheme}
      className={cn(
        "relative flex items-center rounded-xl transition-all duration-300 group overflow-hidden",
        "bg-white/20 dark:bg-slate-800/20 backdrop-blur-sm border border-white/20 dark:border-white/10",
        "hover:bg-white/40 dark:hover:bg-slate-800/40 hover:shadow-lg hover:-translate-y-0.5",
        "focus:outline-none focus:ring-2 focus:ring-turquoise-500/50 focus:ring-offset-2 focus:ring-offset-transparent",
        state === "expanded" ? "w-full justify-start px-4 py-2.5" : "h-9 w-9 justify-center",
        isAnimating && "animate-pulse",
      )}
      aria-label="Toggle theme"
    >
      <div
        className={cn(
          "absolute inset-0 opacity-0 group-hover:opacity-20 transition-all duration-500",
          isDark
            ? "bg-gradient-to-tr from-blue-500 via-cyan-500 to-teal-500"
            : "bg-gradient-to-tr from-amber-500 via-orange-500 to-red-500",
        )}
      />

      <div
        className={cn(
          "absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300",
          isDark ? "shadow-lg shadow-blue-500/20" : "shadow-lg shadow-amber-500/20",
        )}
      />

      <div className="relative z-10 flex items-center">{buttonContent}</div>

      {isAnimating && (
        <div className="absolute inset-0 rounded-xl">
          <div
            className={cn("absolute inset-0 rounded-xl animate-ping", isDark ? "bg-blue-500/30" : "bg-slate-50/30")}
          />
        </div>
      )}
    </button>
  )
}
