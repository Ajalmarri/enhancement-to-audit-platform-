import { NextResponse } from "next/server"
import { ActionPlanSchema } from "@/lib/actionPlanSchema"
import type { ActionPlan } from "@/app/(main)/action-plans/_types/action-plan-types"

const memoryStore: ActionPlan[] = [] // fallback when no external API

export async function GET() {
  if (process.env.API_URL) {
    const res = await fetch(`${process.env.API_URL}/action-plans`, { cache: "no-store" })
    const data = await res.json()
    return NextResponse.json(data, { status: res.ok ? 200 : res.status })
  }
  return NextResponse.json(memoryStore, { status: 200 })
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const parsed = ActionPlanSchema.safeParse({
      ...body,
      progress: typeof body?.progress === "string" ? Number(body.progress) : body?.progress,
    })
    if (!parsed.success) {
      return NextResponse.json({ message: parsed.error.issues.map((i) => i.message).join(", ") }, { status: 400 })
    }

    const fullActionPlan: ActionPlan = {
      id: parsed.data.id,
      findingId: parsed.data.findingId,
      findingTitle: parsed.data.finding, // Map 'finding' to 'findingTitle'
      businessOwner: parsed.data.businessOwner,
      auditorInCharge: parsed.data.auditorInCharge,
      overallObjective: `Address finding: ${parsed.data.finding}`, // Default objective
      items: [], // Start with empty items array
      submittedDate: new Date().toISOString().split("T")[0],
      lastUpdated: parsed.data.lastUpdated || new Date().toISOString().split("T")[0],
      progress: parsed.data.progress,
      status: parsed.data.status as ActionPlan["status"], // Cast to full status type
      reviewFeedback: undefined,
    }

    if (process.env.API_URL) {
      const res = await fetch(`${process.env.API_URL}/action-plans`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(fullActionPlan),
      })
      const created = await res.json()
      if (!res.ok) {
        return NextResponse.json({ message: created?.message || "Create failed" }, { status: res.status })
      }
      return NextResponse.json(created, { status: 201 })
    }

    // Fallback local persist
    const exists = memoryStore.some((ap) => ap.id === fullActionPlan.id)
    if (exists) return NextResponse.json({ message: "ID already exists" }, { status: 409 })

    memoryStore.push(fullActionPlan)
    return NextResponse.json(fullActionPlan, { status: 201 })
  } catch (e: any) {
    return NextResponse.json({ message: e?.message || "Create failed" }, { status: 500 })
  }
}
