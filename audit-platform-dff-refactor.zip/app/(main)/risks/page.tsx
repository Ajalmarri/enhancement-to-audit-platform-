"use client"

import type React from "react"

import { useState } from "react"
import { PremiumButton } from "@/components/ui/premium-button"
import { PremiumInput } from "@/components/ui/premium-input"
import {
  PremiumTable,
  PremiumTableBody,
  PremiumTableCell,
  PremiumTableHead,
  PremiumTableHeader,
  PremiumTableRow,
} from "@/components/ui/premium-table"
import { PremiumStatusBadge } from "@/components/ui/premium-status-badge"
import { PremiumBadge } from "@/components/ui/premium-badge"
import { PremiumCard, PremiumCardHeader, PremiumCardTitle, PremiumCardContent } from "@/components/ui/premium-card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu"

import { PlusCircle, Search, Filter, MoreHorizontal, Edit3, Trash2, Eye, SlidersHorizontal, Shield } from "lucide-react"

type RiskStatus = "Open" | "Mitigated" | "Accepted" | "Closed"
type RiskRating = "Low" | "Medium" | "High" | "Critical"
type RiskCategory = "Enterprise" | "Operational" | "Financial" | "Compliance" | "Strategic"

interface Risk {
  id: string
  title: string
  description: string
  categories: RiskCategory[]
  status: RiskStatus
  inherentRisk: RiskRating
  residualRisk: RiskRating
  lastUpdated: string
  // Placeholder for controls information
  controlsCount?: number
}

const mockRisks: Risk[] = [
  {
    id: "RISK001",
    title: "Data Breach due to Unpatched Systems",
    description:
      "Potential unauthorized access to sensitive customer data through vulnerabilities in unpatched software.",
    categories: ["Operational", "Enterprise"],
    status: "Open",
    inherentRisk: "Critical",
    residualRisk: "High",
    lastUpdated: "2025-05-28",
    controlsCount: 3,
  },
  {
    id: "RISK002",
    title: "Financial Misstatement from Manual Errors",
    description:
      "Risk of errors in financial reporting due to reliance on manual data entry and reconciliation processes.",
    categories: ["Financial", "Operational"],
    status: "Mitigated",
    inherentRisk: "High",
    residualRisk: "Low",
    lastUpdated: "2025-05-15",
    controlsCount: 5,
  },
  {
    id: "RISK003",
    title: "Regulatory Non-Compliance with GDPR",
    description: "Failure to adhere to GDPR requirements leading to potential fines and reputational damage.",
    categories: ["Compliance", "Enterprise"],
    status: "Open",
    inherentRisk: "High",
    residualRisk: "Medium",
    lastUpdated: "2025-06-01",
    controlsCount: 2,
  },
  {
    id: "RISK004",
    title: "Supply Chain Disruption",
    description: "Disruption in key supply chains affecting operational continuity and product delivery.",
    categories: ["Strategic", "Operational"],
    status: "Accepted",
    inherentRisk: "Medium",
    residualRisk: "Medium",
    lastUpdated: "2025-04-20",
    controlsCount: 1,
  },
  {
    id: "RISK005",
    title: "Outdated IT Infrastructure",
    description: "Legacy IT systems are becoming unreliable and difficult to maintain, posing operational risks.",
    categories: ["Operational"],
    status: "Closed",
    inherentRisk: "Medium",
    residualRisk: "Low",
    lastUpdated: "2025-03-10",
    controlsCount: 4,
  },
]

const allCategories: RiskCategory[] = ["Enterprise", "Operational", "Financial", "Compliance", "Strategic"]
const allStatuses: RiskStatus[] = ["Open", "Mitigated", "Accepted", "Closed"]
const allRatings: RiskRating[] = ["Low", "Medium", "High", "Critical"]

export default function RisksPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredRisks, setFilteredRisks] = useState<Risk[]>(mockRisks)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [editingRisk, setEditingRisk] = useState<Risk | null>(null)

  // Placeholder for filter state
  const [statusFilters, setStatusFilters] = useState<Record<RiskStatus, boolean>>({
    Open: false,
    Mitigated: false,
    Accepted: false,
    Closed: false,
  })
  const [categoryFilters, setCategoryFilters] = useState<Record<RiskCategory, boolean>>({
    Enterprise: false,
    Operational: false,
    Financial: false,
    Compliance: false,
    Strategic: false,
  })

  // TODO: Implement actual filtering logic based on searchTerm, statusFilters, categoryFilters
  // This is a simplified search for demonstration
  const handleSearch = (term: string) => {
    setSearchTerm(term)
    if (!term) {
      setFilteredRisks(mockRisks)
      return
    }
    setFilteredRisks(
      mockRisks.filter(
        (risk) =>
          risk.title.toLowerCase().includes(term.toLowerCase()) ||
          risk.description.toLowerCase().includes(term.toLowerCase()),
      ),
    )
  }

  const openAddRiskForm = () => {
    setEditingRisk(null)
    setIsFormOpen(true)
  }

  const openEditRiskForm = (risk: Risk) => {
    setEditingRisk(risk)
    setIsFormOpen(true)
  }

  // Placeholder for delete action
  const handleDeleteRisk = (riskId: string) => {
    console.log("Delete risk:", riskId)
    // Implement actual deletion logic
    setFilteredRisks(filteredRisks.filter((r) => r.id !== riskId))
  }

  // Placeholder for form submission
  const handleFormSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    const newRiskData = {
      id: editingRisk ? editingRisk.id : `RISK${String(mockRisks.length + 1).padStart(3, "0")}`,
      title: formData.get("title") as string,
      description: formData.get("description") as string,
      categories: allCategories.filter((cat) => formData.get(cat)), // Simplified
      status: formData.get("status") as RiskStatus,
      inherentRisk: formData.get("inherentRisk") as RiskRating,
      residualRisk: formData.get("residualRisk") as RiskRating,
      lastUpdated: new Date().toISOString().split("T")[0],
    }
    // TODO: Add/Update risk in mockRisks or backend
    console.log("Form submitted:", newRiskData)
    setIsFormOpen(false)
    setEditingRisk(null)
    // For demo, just re-filter or re-fetch
    handleSearch(searchTerm)
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-4xl font-poppins font-bold bg-gradient-to-r from-navy-900 to-turquoise-600 bg-clip-text text-transparent">
          Manage Risks
        </h1>
        <PremiumButton onClick={openAddRiskForm} className="w-full sm:w-auto">
          <PlusCircle className="mr-2 h-5 w-5" /> Add New Risk
        </PremiumButton>
      </div>

      <PremiumCard variant="glass" icon={<Shield className="h-5 w-5" />}>
        <PremiumCardHeader>
          <PremiumCardTitle>RISK LIBRARY</PremiumCardTitle>
          <div className="mt-4 flex flex-col sm:flex-row items-center gap-4">
            <div className="relative w-full sm:flex-grow">
              <PremiumInput
                placeholder="Search risks by title or description..."
                value={searchTerm}
                onChange={(e) => handleSearch(e.target.value)}
                icon={<Search className="h-4 w-4" />}
                variant="glass"
                className="w-full"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <PremiumButton variant="outline" className="w-full sm:w-auto">
                  <SlidersHorizontal className="mr-2 h-4 w-4" /> Filters
                </PremiumButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[250px]">
                <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {allStatuses.map((status) => (
                  <DropdownMenuCheckboxItem
                    key={status}
                    checked={statusFilters[status]}
                    onCheckedChange={(checked) => setStatusFilters((prev) => ({ ...prev, [status]: !!checked }))}
                  >
                    {status}
                  </DropdownMenuCheckboxItem>
                ))}
                <DropdownMenuLabel className="mt-2">Filter by Category</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {allCategories.map((category) => (
                  <DropdownMenuCheckboxItem
                    key={category}
                    checked={categoryFilters[category]}
                    onCheckedChange={(checked) => setCategoryFilters((prev) => ({ ...prev, [category]: !!checked }))}
                  >
                    {category}
                  </DropdownMenuCheckboxItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </PremiumCardHeader>

        <PremiumCardContent>
          <div className="rounded-2xl overflow-hidden">
            <PremiumTable variant="glass">
              <PremiumTableHeader>
                <PremiumTableRow striped={false}>
                  <PremiumTableHead className="w-[300px]">Risk Details</PremiumTableHead>
                  <PremiumTableHead>Categories</PremiumTableHead>
                  <PremiumTableHead>Status</PremiumTableHead>
                  <PremiumTableHead>Inherent Risk</PremiumTableHead>
                  <PremiumTableHead>Residual Risk</PremiumTableHead>
                  <PremiumTableHead>Last Updated</PremiumTableHead>
                  <PremiumTableHead className="text-right">Actions</PremiumTableHead>
                </PremiumTableRow>
              </PremiumTableHeader>
              <PremiumTableBody>
                {filteredRisks.length > 0 ? (
                  filteredRisks.map((risk, index) => (
                    <PremiumTableRow
                      key={risk.id}
                      style={{ animationDelay: `${index * 100}ms` }}
                      className="animate-fade-in"
                    >
                      <PremiumTableCell>
                        <div className="space-y-1">
                          <div className="font-semibold text-foreground font-poppins" title={risk.title}>
                            {risk.title}
                          </div>
                          <div className="text-xs text-muted-foreground line-clamp-2" title={risk.description}>
                            {risk.description}
                          </div>
                        </div>
                      </PremiumTableCell>
                      <PremiumTableCell>
                        <div className="flex flex-wrap gap-1">
                          {risk.categories.map((category) => (
                            <PremiumBadge key={category} variant="glass" size="sm">
                              {category}
                            </PremiumBadge>
                          ))}
                        </div>
                      </PremiumTableCell>
                      <PremiumTableCell>
                        <PremiumStatusBadge
                          status={risk.status.toLowerCase().replace(" ", "-") as any}
                          animated={risk.status === "Open"}
                        >
                          {risk.status}
                        </PremiumStatusBadge>
                      </PremiumTableCell>
                      <PremiumTableCell>
                        <PremiumStatusBadge
                          status={risk.inherentRisk.toLowerCase() as any}
                          animated={risk.inherentRisk === "Critical"}
                        >
                          {risk.inherentRisk}
                        </PremiumStatusBadge>
                      </PremiumTableCell>
                      <PremiumTableCell>
                        <PremiumStatusBadge status={risk.residualRisk.toLowerCase() as any}>
                          {risk.residualRisk}
                        </PremiumStatusBadge>
                      </PremiumTableCell>
                      <PremiumTableCell>
                        <div className="text-sm font-medium text-muted-foreground">{risk.lastUpdated}</div>
                      </PremiumTableCell>
                      <PremiumTableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <PremiumButton variant="ghost" size="icon">
                              <MoreHorizontal className="h-5 w-5" />
                              <span className="sr-only">Actions</span>
                            </PremiumButton>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => console.log("View details for", risk.id)}>
                              <Eye className="mr-2 h-4 w-4" /> View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openEditRiskForm(risk)}>
                              <Edit3 className="mr-2 h-4 w-4" /> Edit Risk
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => console.log("Manage controls for", risk.id)}>
                              <Filter className="mr-2 h-4 w-4" /> Manage Controls ({risk.controlsCount || 0})
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600" onClick={() => handleDeleteRisk(risk.id)}>
                              <Trash2 className="mr-2 h-4 w-4" /> Delete Risk
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </PremiumTableCell>
                    </PremiumTableRow>
                  ))
                ) : (
                  <PremiumTableRow>
                    <PremiumTableCell colSpan={7} className="h-24 text-center">
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <Shield className="h-8 w-8 opacity-50" />
                        <span className="font-medium">No risks found</span>
                      </div>
                    </PremiumTableCell>
                  </PremiumTableRow>
                )}
              </PremiumTableBody>
            </PremiumTable>
          </div>
        </PremiumCardContent>
      </PremiumCard>
    </div>
  )
}
