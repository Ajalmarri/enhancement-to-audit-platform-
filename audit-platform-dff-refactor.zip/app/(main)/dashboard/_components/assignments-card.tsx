"use client"

import Link from "next/link"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { ArrowRight, ListChecks, Clock, Calendar } from "lucide-react"

const assignments = [
  {
    id: "1",
    title: "Assignment driven project initiation phase review",
    status: "In Progress",
    dueDate: "2025-06-15",
  },
  {
    id: "2",
    title: "Q2 Financial Controls Audit",
    status: "Due Soon",
    dueDate: "2025-06-08",
  },
  {
    id: "3",
    title: "IT Security Compliance Check",
    status: "Completed",
    dueDate: "2025-05-20",
  },
  {
    id: "4",
    title: "Vendor Risk Assessment",
    status: "Pending",
    dueDate: "2025-07-01",
  },
]

export default function AssignmentsCard() {
  const totalAssignments = 123
  const dueSoonAssignments = 50

  return (
    <Card className="rounded-2xl shadow-md bg-white border border-slate-200 h-full">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-poppins font-bold text-slate-900 tracking-wide">
              ASSIGNMENTS OVERVIEW
            </CardTitle>
            <p className="text-sm text-slate-600 mt-1">Track and manage your current tasks</p>
          </div>
          <Link
            href="/assignments"
            className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-teal-600 hover:text-teal-700 hover:bg-teal-50 rounded-lg transition-all duration-200"
          >
            View All <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </CardHeader>

      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
          <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow duration-200">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-slate-500">Total Assignments</p>
              <div className="h-10 w-10 rounded-full bg-gradient-to-tr from-teal-400 to-cyan-500 flex items-center justify-center text-white shadow-md">
                <ListChecks className="h-5 w-5" />
              </div>
            </div>
            <h2 className="text-3xl font-bold text-slate-900">{totalAssignments}</h2>
            <p className="text-xs text-emerald-600 mt-1">↗ +12 vs last month</p>
          </div>
          <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow duration-200">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-slate-500">Due Soon</p>
              <div className="h-10 w-10 rounded-full bg-gradient-to-tr from-amber-400 to-orange-500 flex items-center justify-center text-white shadow-md">
                <Clock className="h-5 w-5" />
              </div>
            </div>
            <h2 className="text-3xl font-bold text-slate-900">{dueSoonAssignments}</h2>
            <p className="text-xs text-dff-warning mt-1">8 urgent items</p>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-poppins font-semibold text-slate-500 uppercase tracking-wide mb-3">
            Recent Assignments
          </h3>
          {assignments.slice(0, 3).map((assignment, index) => (
            <Link
              key={assignment.id}
              href={`/assignments/${assignment.id}`}
              className="block group"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="p-4 bg-white rounded-xl border border-slate-200 hover:bg-slate-50 hover:shadow-md hover:-translate-y-1 transition-all duration-300 cursor-pointer">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-slate-900 truncate group-hover:text-teal-700 transition-colors duration-200">
                      {assignment.title}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <Calendar className="h-3 w-3 text-slate-400" />
                      <p className="text-xs text-slate-500">Due: {assignment.dueDate}</p>
                    </div>
                  </div>
                  <span
                    className={`px-3 py-1 text-xs font-medium rounded-full ${
                      assignment.status === "In Progress"
                        ? "bg-blue-100 text-blue-700"
                        : assignment.status === "Due Soon"
                          ? "bg-slate-50 text-dff-warning"
                          : assignment.status === "Completed"
                            ? "bg-emerald-100 text-emerald-700"
                            : "bg-slate-100 text-slate-700"
                    }`}
                  >
                    {assignment.status}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
