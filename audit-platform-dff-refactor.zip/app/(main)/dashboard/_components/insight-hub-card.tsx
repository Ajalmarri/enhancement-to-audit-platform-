"use client"

import type React from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { SurfaceCard } from "@/components/ui/surface-card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart"
import type { FindingStatus } from "../../../findings/_types/finding-types"
import { TimerOff, ShieldAlert, FileClock, type LucideIcon } from "lucide-react"

// ... existing data arrays ...
const taskCompletionData = [
  { name: "Audit Alpha", completed: 75, pending: 25 },
  { name: "Project Beta", completed: 90, pending: 10 },
  { name: "Review Gamma", completed: 60, pending: 40 },
  { name: "Check Delta", completed: 82, pending: 18 },
]

const resourceRiskData = [
  { month: "Jan", riskScore: 30 },
  { month: "Feb", riskScore: 45 },
  { month: "Mar", riskScore: 40 },
  { month: "Apr", riskScore: 55 },
  { month: "May", riskScore: 50 },
]

const findingsStatusData: { name: FindingStatus | "Overdue"; value: number; label: string }[] = [
  { name: "Pending Verification", value: 10, label: "Pending Verification" },
  { name: "Resolved", value: 40, label: "Resolved" },
  { name: "Sent to Business Owner", value: 15, label: "Sent to BO" },
  { name: "In Remediation", value: 8, label: "In Remediation" },
  { name: "Action Plan Submitted", value: 12, label: "Action Plan Submitted" },
  { name: "Overdue", value: 5, label: "Overdue" },
]

const actionPlanStatusData = [
  { name: "AP_Completed", value: 55, label: "Completed" },
  { name: "AP_InProgress", value: 20, label: "In Progress" },
  { name: "AP_Overdue", value: 12, label: "Overdue" },
  { name: "AP_NotStarted", value: 10, label: "Not Started" },
]

const projectedWorkloadData = [
  { month: "July '25", plannedWork: 150, teamCapacity: 160 },
  { month: "August '25", plannedWork: 170, teamCapacity: 160 },
  { month: "September '25", plannedWork: 140, teamCapacity: 160 },
]

const efficiencyMetricsData = [
  { label: "Avg. Finding Resolution Time", value: "22 Days" },
  { label: "Avg. Audit Cycle Time", value: "45 Days" },
  { label: "Overdue Tasks / Total Tasks", value: "8%" },
]

const chartConfig = {
  completed: { label: "Completed", color: "hsl(var(--chart-1))" },
  pending: { label: "Pending", color: "hsl(var(--chart-2))" },
  riskScore: { label: "Risk Score", color: "hsl(var(--chart-3))" },
  "Pending Verification": { label: "Pending Verification", color: "hsl(var(--chart-4))" },
  Resolved: { label: "Resolved", color: "hsl(var(--chart-5))" },
  "Sent to Business Owner": { label: "Sent to BO", color: "hsl(var(--chart-6))" },
  "In Remediation": { label: "In Remediation", color: "hsl(var(--chart-7))" },
  "Action Plan Submitted": { label: "Action Plan Submitted", color: "hsl(var(--chart-8))" },
  Overdue: { label: "Overdue", color: "hsl(var(--chart-danger))" },
  AP_Completed: { label: "Completed", color: "hsl(var(--chart-1))" },
  AP_InProgress: { label: "In Progress", color: "hsl(var(--chart-2))" },
  AP_Overdue: { label: "Overdue", color: "hsl(var(--chart-danger))" },
  AP_NotStarted: { label: "Not Started", color: "hsl(var(--chart-4))" },
  plannedWork: { label: "Planned Work", color: "hsl(var(--chart-3))" },
  teamCapacity: { label: "Team Capacity", color: "hsl(var(--chart-1))" },
} satisfies Record<string, { label: string; color: string; icon?: React.ComponentType }>

interface StatCardProps {
  title: string
  value: string
  icon: LucideIcon
  link: string
  query?: Record<string, string>
}

const statCardsData: StatCardProps[] = [
  {
    title: "Overdue Action Plans",
    value: "12",
    icon: TimerOff,
    link: "/action-plans",
    query: { status: "Overdue" },
  },
  {
    title: "Open High-Risk Findings",
    value: "7",
    icon: ShieldAlert,
    link: "/findings",
    query: { riskLevel: "High", status: "Open" },
  },
  {
    title: "Reports Pending Approval",
    value: "3",
    icon: FileClock,
    link: "/reports",
    query: { status: "Pending Approval" },
  },
]

export default function InsightHubCard() {
  const router = useRouter()

  const handlePieSegmentClick = (data: any) => {
    if (data && data.name) {
      if (data.name === "Overdue") {
        router.push(`/findings?filter=overdue`)
      } else {
        router.push(`/findings?status=${encodeURIComponent(data.name)}`)
      }
    }
  }

  const handleActionPlanBarClick = (data: any) => {
    if (data && data.name) {
      const statusForQuery = data.name.startsWith("AP_") ? data.name.substring(3) : data.name
      router.push(`/action-plans?status=${encodeURIComponent(statusForQuery)}`)
    }
  }

  return (
    <SurfaceCard className="p-0 overflow-hidden">
      <div className="h-1 w-full bg-gradient-to-r from-dff-teal to-dff-tealSoft" />

      <div className="p-6">
        <div className="mb-6">
          <h2 className="font-heading text-xl font-bold text-dff-navy mb-2">Insight Hub</h2>
          <p className="text-dff-textMuted">Key metrics and trends at a glance.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {statCardsData.map((stat) => (
            <Link href={{ pathname: stat.link, query: stat.query }} key={stat.title} className="block group">
              <SurfaceCard className="p-5 transition-all duration-200 ease-soft hover:shadow-hover hover:-translate-y-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-dff-teal focus-visible:ring-offset-2">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-dff-textMuted mb-1">{stat.title}</p>
                    <div className="text-3xl font-bold text-dff-navy">{stat.value}</div>
                  </div>
                  <div className="h-10 w-10 rounded-full bg-gradient-to-tr from-dff-teal to-dff-tealSoft text-white flex items-center justify-center shadow-card">
                    <stat.icon className="h-5 w-5" />
                  </div>
                </div>
              </SurfaceCard>
            </Link>
          ))}
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-md font-heading font-semibold mb-4 text-center text-dff-navy">Task Completion Rate</h3>
            <ChartContainer config={chartConfig} className="min-h-[200px] w-full">
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={taskCompletionData} margin={{ top: 5, right: 5, left: -25, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis
                    dataKey="name"
                    tickLine={false}
                    axisLine={false}
                    fontSize={10}
                    interval={0}
                    dy={10}
                    tick={{ fill: "#6B7280" }}
                  />
                  <YAxis tickLine={false} axisLine={false} fontSize={10} tick={{ fill: "#6B7280" }} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <ChartLegend content={<ChartLegendContent />} verticalAlign="bottom" />
                  <Bar dataKey="completed" fill="var(--color-completed)" radius={4} />
                  <Bar dataKey="pending" fill="var(--color-pending)" radius={4} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>

          {/* ... existing charts with updated styling ... */}
          <div>
            <h3 className="text-md font-heading font-semibold mb-4 text-center text-dff-navy">Resource Risk Trend</h3>
            <ChartContainer config={chartConfig} className="min-h-[200px] w-full">
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={resourceRiskData} margin={{ top: 5, right: 20, left: -25, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis
                    dataKey="month"
                    tickLine={false}
                    axisLine={false}
                    fontSize={10}
                    interval={0}
                    dy={10}
                    tick={{ fill: "#6B7280" }}
                  />
                  <YAxis tickLine={false} axisLine={false} fontSize={10} tick={{ fill: "#6B7280" }} />
                  <ChartTooltip content={<ChartTooltipContent indicator="line" />} />
                  <ChartLegend content={<ChartLegendContent />} verticalAlign="bottom" />
                  <Line
                    type="monotone"
                    dataKey="riskScore"
                    stroke="var(--color-riskScore)"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>

          <div>
            <h3 className="text-md font-heading font-semibold mb-4 text-center text-dff-navy">Findings by Status</h3>
            <ChartContainer config={chartConfig} className="min-h-[200px] w-full">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart margin={{ top: 5, right: 5, left: 5, bottom: 20 }}>
                  <ChartTooltip content={<ChartTooltipContent nameKey="label" />} />
                  <Pie
                    data={findingsStatusData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={70}
                    strokeWidth={2}
                    onClick={handlePieSegmentClick}
                    className="cursor-pointer"
                  >
                    {findingsStatusData.map((entry) => (
                      <Cell
                        key={`cell-finding-${entry.name}`}
                        fill={chartConfig[entry.name as keyof typeof chartConfig]?.color || "#8884d8"}
                        className="focus:outline-none hover:opacity-80"
                      />
                    ))}
                  </Pie>
                  <ChartLegend content={<ChartLegendContent nameKey="label" />} verticalAlign="bottom" />
                </PieChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>

          <div>
            <h3 className="text-md font-heading font-semibold mb-4 text-center text-dff-navy">Action Plan Status</h3>
            <ChartContainer config={chartConfig} className="min-h-[200px] w-full">
              <ResponsiveContainer width="100%" height={200}>
                <BarChart
                  data={actionPlanStatusData}
                  layout="vertical"
                  margin={{ top: 5, right: 20, left: 50, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                  <XAxis type="number" tickLine={false} axisLine={false} fontSize={10} tick={{ fill: "#6B7280" }} />
                  <YAxis
                    dataKey="label"
                    type="category"
                    tickLine={false}
                    axisLine={false}
                    fontSize={10}
                    width={80}
                    interval={0}
                    tick={{ fill: "#6B7280" }}
                  />
                  <ChartTooltip
                    cursor={{ fill: "rgba(148, 163, 184, 0.1)" }}
                    content={<ChartTooltipContent nameKey="label" indicator="line" />}
                  />
                  <ChartLegend content={<ChartLegendContent nameKey="label" />} verticalAlign="bottom" />
                  <Bar dataKey="value" radius={4} onClick={handleActionPlanBarClick} className="cursor-pointer">
                    {actionPlanStatusData.map((entry) => (
                      <Cell
                        key={`cell-ap-${entry.name}`}
                        fill={chartConfig[entry.name as keyof typeof chartConfig]?.color || "#8884d8"}
                        className="focus:outline-none hover:opacity-80"
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>

          <div className="md:col-span-2 p-1">
            <h3 className="text-md font-heading font-semibold mb-6 text-center text-dff-navy">
              Resource Forecasting & Efficiency
            </h3>

            <div className="mb-6">
              <h4 className="text-sm font-medium mb-4 text-center text-dff-textMuted">
                Projected Team Workload vs. Capacity
              </h4>
              <ChartContainer config={chartConfig} className="min-h-[200px] w-full">
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={projectedWorkloadData} margin={{ top: 5, right: 5, left: -25, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis
                      dataKey="month"
                      tickLine={false}
                      axisLine={false}
                      fontSize={10}
                      interval={0}
                      dy={10}
                      tick={{ fill: "#6B7280" }}
                    />
                    <YAxis tickLine={false} axisLine={false} fontSize={10} unit="h" tick={{ fill: "#6B7280" }} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <ChartLegend content={<ChartLegendContent />} verticalAlign="bottom" />
                    <Bar dataKey="plannedWork" fill="var(--color-plannedWork)" radius={4} name="Planned Work (hrs)" />
                    <Bar
                      dataKey="teamCapacity"
                      fill="var(--color-teamCapacity)"
                      radius={4}
                      name="Team Capacity (hrs)"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>

            <div>
              <h4 className="text-sm font-medium mb-4 text-center text-dff-textMuted">Audit Efficiency Metrics</h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {efficiencyMetricsData.map((metric) => (
                  <SurfaceCard key={metric.label} className="p-5 text-center">
                    <div className="h-1 w-full bg-gradient-to-r from-dff-teal to-dff-tealSoft rounded-full mb-3"></div>
                    <p className="text-xs font-medium text-dff-textMuted truncate mb-2" title={metric.label}>
                      {metric.label}
                    </p>
                    <p className="text-2xl font-bold text-dff-navy">{metric.value}</p>
                  </SurfaceCard>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </SurfaceCard>
  )
}
