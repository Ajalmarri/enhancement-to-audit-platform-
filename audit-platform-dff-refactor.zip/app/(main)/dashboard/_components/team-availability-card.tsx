"use client"

import { PremiumCard, PremiumCardHeader, PremiumCardTitle, PremiumCardContent } from "@/components/ui/premium-card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { PremiumBadge } from "@/components/ui/premium-badge"
import { Users } from "lucide-react"

const teamMembers = [
  {
    id: "1",
    name: "Khaled M.",
    avatarUrl: "/placeholder.svg?width=40&height=40",
    status: "Available",
    role: "Lead Auditor",
  },
  {
    id: "2",
    name: "Yema al Olman",
    avatarUrl: "/placeholder.svg?width=40&height=40",
    status: "Busy",
    role: "Senior Auditor",
  },
  {
    id: "3",
    name: "Fatima H.",
    avatarUrl: "/placeholder.svg?width=40&height=40",
    status: "Available",
    role: "Auditor",
  },
  {
    id: "4",
    name: "Omar S.",
    avatarUrl: "/placeholder.svg?width=40&height=40",
    status: "On Leave",
    role: "Junior Auditor",
  },
]

const statusVariants: { [key: string]: "success" | "warning" | "glass" } = {
  Available: "success",
  Busy: "warning",
  "On Leave": "glass",
}

export default function TeamAvailabilityCard() {
  return (
    <PremiumCard variant="glass" icon={<Users className="h-5 w-5" />} className="h-full">
      <PremiumCardHeader>
        <PremiumCardTitle>TEAM AVAILABILITY</PremiumCardTitle>
        <p className="text-sm text-muted-foreground mt-1">Current status of team members</p>
      </PremiumCardHeader>

      <PremiumCardContent>
        <div className="space-y-3">
          {teamMembers.map((member, index) => (
            <div
              key={member.id}
              className="flex items-center justify-between p-3 bg-white/20 dark:bg-slate-800/20 backdrop-blur-sm rounded-xl border border-white/20 dark:border-white/10 hover:bg-white/40 dark:hover:bg-slate-800/40 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 group"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Avatar className="h-10 w-10 ring-2 ring-white/20 dark:ring-white/10 group-hover:ring-turquoise-500/30 transition-all duration-300">
                    <AvatarImage src={member.avatarUrl || "/placeholder.svg"} alt={member.name} />
                    <AvatarFallback className="bg-gradient-to-br from-turquoise-500 to-turquoise-600 text-white font-poppins font-semibold">
                      {member.name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div
                    className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-white dark:border-slate-900 ${
                      member.status === "Available"
                        ? "bg-emerald-500 shadow-lg shadow-emerald-500/50"
                        : member.status === "Busy"
                          ? "bg-slate-50 shadow-lg shadow-amber-500/50"
                          : "bg-slate-400 shadow-lg shadow-slate-400/50"
                    }`}
                  />
                </div>
                <div>
                  <p className="font-medium text-foreground font-poppins">{member.name}</p>
                  <p className="text-xs text-muted-foreground">{member.role}</p>
                </div>
              </div>
              <PremiumBadge variant={statusVariants[member.status]} size="sm" pulse={member.status === "Busy"}>
                {member.status}
              </PremiumBadge>
            </div>
          ))}
        </div>
      </PremiumCardContent>
    </PremiumCard>
  )
}
