"use client"

import { PremiumCard, PremiumCardHeader, PremiumCardTitle, PremiumCardContent } from "@/components/ui/premium-card"
import { Calendar } from "@/components/ui/calendar"
import { CalendarDays } from "lucide-react"
import { useState } from "react"

export default function CalendarCard() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  return (
    <PremiumCard variant="glass" icon={<CalendarDays className="h-5 w-5" />} className="h-full">
      <PremiumCardHeader>
        <PremiumCardTitle>CALENDAR</PremiumCardTitle>
        <p className="text-sm text-muted-foreground mt-1">Upcoming deadlines and events</p>
      </PremiumCardHeader>

      <PremiumCardContent>
        <div className="flex justify-center">
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            className="rounded-xl bg-white/20 dark:bg-slate-800/20 backdrop-blur-sm border border-white/20 dark:border-white/10 shadow-lg"
            classNames={{
              month: "space-y-3 p-4",
              caption_label: "text-sm font-poppins font-semibold text-foreground",
              nav_button:
                "h-8 w-8 bg-white/20 dark:bg-slate-800/20 backdrop-blur-sm border border-white/20 dark:border-white/10 rounded-lg hover:bg-white/40 dark:hover:bg-slate-800/40 transition-all duration-200",
              nav_button_previous: "absolute left-2",
              nav_button_next: "absolute right-2",
              table: "w-full border-collapse space-y-1",
              head_row: "flex",
              head_cell:
                "text-muted-foreground rounded-lg w-10 font-medium text-xs font-poppins uppercase tracking-wide",
              row: "flex w-full mt-2",
              cell: "h-10 w-10 text-center text-sm p-0 relative [&:has([aria-selected].day-range-end)]:rounded-r-lg [&:has([aria-selected].day-outside)]:bg-accent/50 [&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-lg last:[&:has([aria-selected])]:rounded-r-lg focus-within:relative focus-within:z-20",
              day: "h-10 w-10 p-0 font-medium aria-selected:opacity-100 rounded-lg hover:bg-white/20 dark:hover:bg-slate-800/20 transition-all duration-200",
              day_range_end: "day-range-end",
              day_selected:
                "bg-gradient-to-r from-turquoise-500 to-turquoise-600 text-white hover:from-turquoise-600 hover:to-turquoise-700 focus:from-turquoise-600 focus:to-turquoise-700 shadow-lg",
              day_today:
                "bg-white/30 dark:bg-slate-800/30 text-turquoise-600 dark:text-turquoise-400 font-bold border border-turquoise-500/30",
              day_outside:
                "day-outside text-muted-foreground opacity-50 aria-selected:bg-accent/50 aria-selected:text-muted-foreground aria-selected:opacity-30",
              day_disabled: "text-muted-foreground opacity-30",
              day_hidden: "invisible",
            }}
          />
        </div>
      </PremiumCardContent>
    </PremiumCard>
  )
}
