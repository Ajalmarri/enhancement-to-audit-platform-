"use client"

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ChevronDown, Settings, PlusCircle, Sparkles } from "lucide-react"
import type { DashboardView, AllDashboardViews } from "../_types/dashboard-types"

interface DashboardHeaderProps {
  userName: string
  activeView: DashboardView
  allViews: AllDashboardViews
  onSwitchView: (viewId: string) => void
  onCustomize: () => void
  onCreateNewView: () => void
}

export default function DashboardHeader({
  userName,
  activeView,
  allViews,
  onSwitchView,
  onCustomize,
  onCreateNewView,
}: DashboardHeaderProps) {
  const greeting = `Good morning, ${userName}!`
  const otherViews = Object.values(allViews).filter((v) => v.id !== activeView.id)

  return (
    <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
      <div className="space-y-2">
        <h1 className="text-4xl font-poppins font-bold text-slate-900">{greeting}</h1>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 hover:border-teal-300 transition-all duration-300 group shadow-sm">
                <Sparkles className="h-4 w-4 text-teal-500 group-hover:text-teal-600 transition-colors duration-200" />
                <span className="text-lg font-poppins font-semibold text-slate-900 group-hover:text-teal-700 transition-colors duration-200">
                  {activeView.name}
                </span>
                <ChevronDown className="h-4 w-4 text-slate-500 group-hover:text-teal-500 transition-colors duration-200" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-64 bg-white border border-slate-200 shadow-lg rounded-xl">
              <DropdownMenuLabel className="font-poppins font-semibold text-slate-900">Switch View</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {otherViews.map((view) => (
                <DropdownMenuItem
                  key={view.id}
                  onSelect={() => onSwitchView(view.id)}
                  className="font-medium hover:bg-slate-50 hover:text-teal-700 rounded-lg mx-1"
                >
                  {view.name}
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onSelect={onCreateNewView}
                className="font-medium hover:bg-slate-50 hover:text-teal-700 rounded-lg mx-1"
              >
                <PlusCircle className="mr-2 h-4 w-4" />
                <span>Create New View</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <button
        onClick={onCustomize}
        className="shrink-0 flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-medium rounded-xl hover:from-teal-600 hover:to-cyan-700 transition-all duration-300 shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
      >
        <Settings className="h-4 w-4" />
        Customize View
      </button>
    </div>
  )
}
