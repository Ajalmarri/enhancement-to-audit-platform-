"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/components/ui/use-toast"
import {
  ArrowLeft,
  Edit,
  FileText,
  Target,
  Users,
  Calendar,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  User,
  Building,
} from "lucide-react"

import type { ActionPlan, ActionPlanStatus } from "../_types/action-plan-types"

// Mock data for action plans (same as in the list page)
const mockActionPlans: ActionPlan[] = [
  {
    id: "AP001",
    findingId: "FND001",
    findingTitle: "Unsecured S3 Bucket Exposing Sensitive Data",
    businessOwner: "IT Security Manager",
    auditorInCharge: "Alice Wonderland",
    overallObjective: "Secure all S3 buckets and implement proper access controls",
    items: [
      {
        id: "AP001-1",
        action: "Restrict public access",
        responsiblePerson: "Cloud Team",
        dueDate: "2025-06-15",
        status: "Completed",
      },
      {
        id: "AP001-2",
        action: "Review policies",
        responsiblePerson: "Cloud Team",
        dueDate: "2025-06-20",
        status: "In Progress",
      },
    ],
    submittedDate: "2025-06-05",
    lastUpdated: "2025-06-10",
    progress: 50,
    status: "In Progress",
  },
  {
    id: "AP002",
    findingId: "FND002",
    findingTitle: "Lack of Segregation of Duties",
    businessOwner: "Finance Head",
    auditorInCharge: "Bob The Builder",
    overallObjective: "Implement proper SoD for financial reporting",
    items: [
      {
        id: "AP002-1",
        action: "Review roles",
        responsiblePerson: "Finance Admin",
        dueDate: "2025-07-15",
        status: "To Do",
      },
    ],
    submittedDate: "2025-06-10",
    lastUpdated: "2025-06-10",
    progress: 0,
    status: "Submitted for Review",
    reviewFeedback:
      "The initial plan looks good, but please add specific sub-tasks for training staff on the new SoD policies.",
  },
  {
    id: "AP003",
    findingId: "FND003",
    findingTitle: "Outdated Anti-Virus",
    businessOwner: "IT Operations Lead",
    auditorInCharge: "Alice Wonderland",
    overallObjective: "Ensure all servers have up-to-date AV",
    items: [
      {
        id: "AP003-1",
        action: "Update AV",
        responsiblePerson: "SysAdmin Team",
        dueDate: "2025-06-10",
        status: "Completed",
      },
    ],
    submittedDate: "2025-06-02",
    lastUpdated: "2025-06-18",
    progress: 100,
    status: "Completed",
  },
  {
    id: "AP004",
    findingId: "FND004",
    findingTitle: "Inadequate Password Policy",
    businessOwner: "IT Security Manager",
    auditorInCharge: "Charlie Brown",
    overallObjective: "Strengthen password policies",
    items: [
      {
        id: "AP004-1",
        action: "Update policy",
        responsiblePerson: "IDM Team",
        dueDate: "2025-05-20",
        status: "Blocked",
      },
    ],
    submittedDate: "2025-06-12",
    lastUpdated: "2025-06-12",
    progress: 0,
    status: "Submitted for Review",
  },
  {
    id: "AP005",
    findingId: "FND005",
    findingTitle: "Missing Backup Verification",
    businessOwner: "Data Management Lead",
    auditorInCharge: "Bob The Builder",
    overallObjective: "Establish backup verification",
    items: [
      {
        id: "AP005-1",
        action: "Document procedures",
        responsiblePerson: "Backup Lead",
        dueDate: "2025-04-15",
        status: "Completed",
      },
    ],
    submittedDate: "2025-05-01",
    lastUpdated: "2025-06-15",
    progress: 30,
    status: "Changes Requested",
    reviewFeedback:
      "The documented procedures are not detailed enough. Please include step-by-step instructions for verification and expected outcomes.",
  },
]

// Status configuration
const actionPlanStatusConfig: Record<
  ActionPlanStatus,
  { icon: React.ElementType; color: string; badgeVariant?: "default" | "secondary" | "destructive" | "outline" }
> = {
  "Not Started": { icon: Clock, color: "text-gray-500", badgeVariant: "secondary" },
  "In Progress": { icon: Clock, color: "text-blue-500", badgeVariant: "secondary" },
  Completed: { icon: CheckCircle, color: "text-green-500", badgeVariant: "default" },
  Overdue: { icon: AlertTriangle, color: "text-red-500", badgeVariant: "destructive" },
  "At Risk": { icon: XCircle, color: "text-orange-500", badgeVariant: "secondary" },
  "Submitted for Review": { icon: FileText, color: "text-purple-500", badgeVariant: "secondary" },
  "Changes Requested": { icon: AlertTriangle, color: "text-dff-warning", badgeVariant: "secondary" },
}

const itemStatusConfig = {
  "To Do": { icon: Clock, color: "text-gray-500", bgColor: "bg-gray-100" },
  "In Progress": { icon: Clock, color: "text-blue-500", bgColor: "bg-blue-100" },
  Completed: { icon: CheckCircle, color: "text-green-500", bgColor: "bg-green-100" },
  Blocked: { icon: XCircle, color: "text-red-500", bgColor: "bg-red-100" },
}

export default function ActionPlanDetailPage() {
  const params = useParams()
  const router = useRouter()
  const planId = params.planId as string

  const [actionPlan, setActionPlan] = useState<ActionPlan | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate API call to fetch action plan details
    const fetchActionPlan = async () => {
      try {
        // In a real app, this would be an API call
        await new Promise((resolve) => setTimeout(resolve, 500))

        const plan = mockActionPlans.find((p) => p.id === planId)
        if (plan) {
          setActionPlan(plan)
        } else {
          throw new Error("Action plan not found")
        }
      } catch (error) {
        toast({
          title: "Error",
          description: "Action plan not found or failed to load.",
          variant: "destructive",
        })
        router.push("/action-plans")
      } finally {
        setIsLoading(false)
      }
    }

    fetchActionPlan()
  }, [planId, router])

  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="animate-pulse space-y-8">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-32 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    )
  }

  if (!actionPlan) {
    return (
      <div className="max-w-5xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="text-center">
          <h1 className="text-2xl font-semibold text-foreground">Action Plan Not Found</h1>
          <p className="text-muted-foreground mt-2">The requested action plan could not be found.</p>
          <Button asChild className="mt-4">
            <Link href="/action-plans">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Action Plans
            </Link>
          </Button>
        </div>
      </div>
    )
  }

  const statusInfo = actionPlanStatusConfig[actionPlan.status]

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6 lg:p-8">
      <div className="mb-6">
        <Button variant="outline" size="sm" asChild className="mb-4 bg-transparent">
          <Link href="/action-plans">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Action Plans
          </Link>
        </Button>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-semibold text-foreground">Action Plan {actionPlan.id}</h1>
            <p className="text-muted-foreground">{actionPlan.findingTitle}</p>
          </div>
          <div className="flex items-center gap-4">
            <Badge
              variant={statusInfo.badgeVariant || "secondary"}
              className={
                actionPlan.status === "Completed"
                  ? "bg-green-500 hover:bg-green-600 text-white"
                  : actionPlan.status === "Overdue"
                    ? "bg-red-500 hover:bg-red-600 text-white"
                    : actionPlan.status === "At Risk"
                      ? "bg-orange-500 hover:bg-orange-600 text-white"
                      : actionPlan.status === "Changes Requested"
                        ? "bg-slate-50 hover:bg-slate-50 text-black"
                        : ""
              }
            >
              <statusInfo.icon className={`mr-1.5 h-3.5 w-3.5 ${statusInfo.color}`} />
              {actionPlan.status}
            </Badge>
            <Button asChild>
              <Link href={`/action-plans/${actionPlan.id}/edit`}>
                <Edit className="mr-2 h-4 w-4" /> Edit Plan
              </Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {/* Overview Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="mr-2 h-5 w-5 text-primary" />
              Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="space-y-2">
                <div className="flex items-center text-sm text-muted-foreground">
                  <Building className="mr-2 h-4 w-4" />
                  Related Finding
                </div>
                <p className="font-medium">{actionPlan.findingId}</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-muted-foreground">
                  <User className="mr-2 h-4 w-4" />
                  Business Owner
                </div>
                <p className="font-medium">{actionPlan.businessOwner}</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-muted-foreground">
                  <User className="mr-2 h-4 w-4" />
                  Auditor-in-Charge
                </div>
                <p className="font-medium">{actionPlan.auditorInCharge || "N/A"}</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-muted-foreground">
                  <Calendar className="mr-2 h-4 w-4" />
                  Last Updated
                </div>
                <p className="font-medium">{new Date(actionPlan.lastUpdated).toLocaleDateString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Progress Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="mr-2 h-5 w-5 text-primary" />
              Progress Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Overall Progress</span>
                <span className="text-sm text-muted-foreground">{actionPlan.progress}%</span>
              </div>
              <Progress value={actionPlan.progress} className="h-3" />
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-green-600">
                    {actionPlan.items.filter((item) => item.status === "Completed").length}
                  </div>
                  <div className="text-xs text-muted-foreground">Completed</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-blue-600">
                    {actionPlan.items.filter((item) => item.status === "In Progress").length}
                  </div>
                  <div className="text-xs text-muted-foreground">In Progress</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-600">
                    {actionPlan.items.filter((item) => item.status === "To Do").length}
                  </div>
                  <div className="text-xs text-muted-foreground">To Do</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-red-600">
                    {actionPlan.items.filter((item) => item.status === "Blocked").length}
                  </div>
                  <div className="text-xs text-muted-foreground">Blocked</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Objective Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="mr-2 h-5 w-5 text-primary" />
              Overall Objective
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-foreground leading-relaxed">{actionPlan.overallObjective}</p>
          </CardContent>
        </Card>

        {/* Action Items Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="mr-2 h-5 w-5 text-primary" />
              Action Items ({actionPlan.items.length})
            </CardTitle>
            <CardDescription>Detailed breakdown of all action items and their current status.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {actionPlan.items.map((item, index) => {
                const itemStatus = itemStatusConfig[item.status]
                return (
                  <Card key={item.id} className="p-4 bg-muted/30">
                    <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold">Action Item #{index + 1}</h4>
                          <Badge
                            variant="outline"
                            className={`${itemStatus.bgColor} ${itemStatus.color} border-current`}
                          >
                            <itemStatus.icon className="mr-1 h-3 w-3" />
                            {item.status}
                          </Badge>
                        </div>
                        <p className="text-foreground">{item.action}</p>
                        <div className="flex flex-col sm:flex-row gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center">
                            <User className="mr-1 h-3 w-3" />
                            {item.responsiblePerson}
                          </div>
                          <div className="flex items-center">
                            <Calendar className="mr-1 h-3 w-3" />
                            Due: {new Date(item.dueDate).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Review Feedback Card (if applicable) */}
        {actionPlan.reviewFeedback && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-dff-warning">
                <AlertTriangle className="mr-2 h-5 w-5" />
                Review Feedback
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-foreground leading-relaxed">{actionPlan.reviewFeedback}</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
