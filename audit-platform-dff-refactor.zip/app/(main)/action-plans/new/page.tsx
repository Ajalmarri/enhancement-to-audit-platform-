"use client"

import type React from "react"

import { useRouter } from "next/navigation"
import { useState } from "react"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"

export default function NewActionPlanPage() {
  const router = useRouter()
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    const fd = new FormData(e.currentTarget)
    const payload = Object.fromEntries(fd.entries())
    payload.progress = Number(payload.progress || 0)

    const res = await fetch("/api/action-plans", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })

    setLoading(false)
    if (!res.ok) {
      const msg = (await res.json().catch(() => ({})))?.message || "Failed to create action plan"
      setError(msg)
      return
    }
    const created = await res.json()
    router.push(`/action-plans/${created.id}`)
  }

  return (
    <div className="p-6 max-w-3xl">
      <h1 className="text-2xl font-bold mb-4">Create New Action Plan</h1>

      <form onSubmit={onSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="id">Action Plan ID</Label>
            <Input id="id" name="id" placeholder="AP006" required />
          </div>

          <div>
            <Label htmlFor="findingId">Finding ID</Label>
            <Input id="findingId" name="findingId" placeholder="FND006" required />
          </div>

          <div className="md:col-span-2">
            <Label htmlFor="finding">Finding</Label>
            <Input id="finding" name="finding" placeholder="Describe the control gap" required />
          </div>

          <div>
            <Label htmlFor="businessOwner">Business Owner</Label>
            <Input id="businessOwner" name="businessOwner" placeholder="IT Security Manager" required />
          </div>

          <div>
            <Label htmlFor="auditorInCharge">Auditor-in-Charge</Label>
            <Input id="auditorInCharge" name="auditorInCharge" placeholder="Alice Wonderland" required />
          </div>

          <div>
            <Label>Status</Label>
            <Select name="status" required>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Completed">Completed</SelectItem>
                <SelectItem value="Changes Requested">Changes Requested</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="progress">Progress (%)</Label>
            <Input id="progress" name="progress" type="number" min={0} max={100} defaultValue={0} />
          </div>

          <div>
            <Label htmlFor="lastUpdated">Last Updated</Label>
            <Input id="lastUpdated" name="lastUpdated" type="date" />
          </div>
        </div>

        {error && <div className="text-red-600 text-sm">{error}</div>}

        <div className="flex gap-3">
          <Button type="submit" disabled={loading}>
            {loading ? "Creating..." : "Create"}
          </Button>
          <Button type="button" variant="secondary" onClick={() => router.push("/action-plans")}>
            Cancel
          </Button>
        </div>
      </form>
    </div>
  )
}
